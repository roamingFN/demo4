<?php
	include 'connect.php';
	include 'session.php';
	include 'inc/php/functions_statusConvert.php';

$error = '';
if($action = isset($_GET['action']) && $_GET['action'] != ''){
	//create new topup requset
	if (!empty($_POST['update-topup'])) {

		$topup_id 			= $_POST['topup_id'];
		$topup_method 		= $_POST['topup_method'];
		$balance 			= $_POST['balance'];
		$transfer_date 		= $_POST['transfer_date'];
		$transfer_time 		= $_POST['transfer_time'];
		$transfer_channel 	= $_POST['transfer_channel'];
		$transfer_bill 		= $_FILES["transfer_bill"]["name"];
		$notes 				= $_POST['notes'];

		if(empty($topup_method)){ $error .= '<li>คุณยังไม่ได้เลือกบัญชีที่โอนเงินเข้า</li>';}
		if(empty($balance)){ $error .= '<li>คุณยังไม่ได้กรอกจำนวนเงิน</li>';}
		if(empty($transfer_date)){ $error .= '<li>คุณยังไม่ได้กรอกวันที่โอนเงิน</li>';}
		if(empty($transfer_time)){ $error .= '<li>คุณยังไม่ได้กรอกเวลาโอนเงิน</li>';}
		if(empty($transfer_channel)){ $error .= '<li>คุณยังไม่ได้กรอกช่องทางการโอนเงิน</li>';}

		$topup_method 		= stripcslashes($topup_method);
		$balance 			= stripcslashes($balance);
		$transfer_date 		= stripcslashes($transfer_date);
		$transfer_time 		= stripcslashes($transfer_time);
		$transfer_channel 	= stripcslashes($transfer_channel);
		$transfer_bill 		= stripcslashes($transfer_bill);
		$notes 				= stripcslashes($notes);

		$topup_method 		= mysql_real_escape_string($topup_method);
		$balance 			= mysql_real_escape_string($balance);
		$transfer_date 		= mysql_real_escape_string($transfer_date);
		$transfer_time 		= mysql_real_escape_string($transfer_time);
		$transfer_channel 	= mysql_real_escape_string($transfer_channel);
		$transfer_bill 		= mysql_real_escape_string($transfer_bill);
		$notes 				= mysql_real_escape_string($notes);

		$transfer_date = str_replace('/', '-', $transfer_date);
		$transfer_date = date('m/d/Y', strtotime($transfer_date));
		$transfer_datetime 	= $transfer_date." ".$transfer_time;
		//echo $transfer_datetime;

		if ($error == '') {

			if ($transfer_bill!=null) {

				$target_dir = "uploads/".$user_id;
				if (!is_dir($target_dir)&& strlen($target_dir)>0) {
					mkdir($target_dir, "0777");
					chmod($target_dir, 0777);
				}
				$target_file = $target_dir . basename($_FILES["transfer_bill"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				if(isset($_POST["topup-request-submit"])) {
				    $check = getimagesize($_FILES["transfer_bill"]["tmp_name"]);
				    if($check !== false) {
				        //echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				}
				// Check if file already exists
				$target_file = file_newname($target_dir,basename($_FILES["transfer_bill"]["name"]));

				// Check file size
				if ($_FILES["transfer_bill"]["size"] > 500000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["transfer_bill"]["tmp_name"], $target_file)) {
				        //echo "The file ". basename( $_FILES["transfer_bill"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}

				$update_topup_req = mysql_query("update customer_request_topup
												set topup_bank = '$topup_method',
												topup_amount = '$balance',
												topup_date = STR_TO_DATE('$transfer_datetime','%c/%e/%Y %T'),
												transfer_method = '$transfer_channel',
												bill_file_directory = '$target_file',
												customer_notes = '$notes'
												where topup_id = '$topup_id'
												and customer_id = '$user_id'");

				if ($update_topup_req) {
					echo '<div class="alert alert-success container" role="alert"><label>แก้ไขข้อมูลการเติมเงินเรียบร้อย</label>  </div>';

				}else{
					echo "fail".mysql_error();
				}

			}else{

				$update_topup_req = mysql_query("update customer_request_topup
												set topup_bank = '$topup_method',
												topup_amount = '$balance',
												topup_date = STR_TO_DATE('$transfer_datetime','%c/%e/%Y %T'),
												transfer_method = '$transfer_channel',
												customer_notes = '$notes'
												where topup_id = '$topup_id'
												and customer_id = '$user_id'");

				if ($update_topup_req) {
					echo '<div class="alert alert-success container" role="alert"><label>แก้ไขข้อมูลการเติมเงินเรียบร้อย</label>  </div>';
				}else{
					echo "fail".mysql_error();
				}
			}
		}else{
			echo '<div class="alert alert-danger container" role="alert"><label>เกิดข้อผิดพลาด</label>'.$error.'</div>';
		}
	}
}
?>
<!DOCTYPE html>
<html>
  <head>
    <?php include 'page_script.php';  ?>
    <style>
    	thead{
			color:#000;
		}
    </style>
  </head>
  <body>
    <?php include 'nav_bar.php';  ?>
	<div class="content manage">
		<?php include 'left_menu.php' ?>
		<div class="menu-content col3">
	<h1>แก้ไขรายการแจ้งโอนเงิน</h1>
		<?php
	$topup_id = $_GET['topup_id'];
	$topup_id = stripcslashes($topup_id);
	$topup_id = mysql_real_escape_string($topup_id);
	$select_topup = mysql_query("select * from customer_request_topup where topup_id = '$topup_id'
		and customer_id = '$user_id' and topup_status = 0");
	if (mysql_num_rows($select_topup)>0) {
		$select_topup_row = mysql_fetch_array($select_topup);
	
	?>
	<h4>&nbsp เลขที่การเติมเงิน : <?php echo $select_topup_row['topup_number']; ?></h4>
	<form role="form" action="topup_edit.php?action=edit<?php echo "&topup_id=".$select_topup_row['topup_id']; ?>" method="post" name="from_topup_req" id="from_topup_req"  enctype="multipart/form-data">
	<table class='content-grid'>
		<tr>
			<th colspan="6" class="bg-primary">เลือกบัญชีที่โอนเงินเข้า</th>
		</tr>
	<?php 
	$select_payment_method = mysql_query("select * from bank_payment");
	if (mysql_num_rows($select_payment_method)>0) {
		while ($row = mysql_fetch_array($select_payment_method)) {
			echo "
			<tr>
				<td><input type='radio' name='topup_method' value='".$row['bank_id']."' ";
				if ($select_topup_row['topup_bank'] == $row['bank_id']) {
					echo "checked";
				}
				echo"></td>
				<td><img style='height:50px;' src='img/".$row['bank_img']."'></td>
				<td>".$row['bank_name_th']."</td>
				<td>".formatBankAccNo($row['account_no'])."</td>
				<td>".$row['account_name']."</td>
				<td>".$row['bank_branch']."</td>
			</tr>
			";
		}
	}
	?>
	</table>
	<br />

	<table class="content-light">
		<tr>
			<th>ยอดเงิน</th>
			<td><input type="text" value="<?php echo $select_topup_row['topup_amount']; ?>" class="form-control" placeholder="จำนวนเงินที่โอน" name="balance" 
			onkeypress="return isNumber(event)" /></td>
		</tr>
		<tr>
			<th>วันที่โอนเงิน</th>
			<td>
				<div class="input-group input-append date" id="datePicker">
                	<input type="text" value="<?php echo date('d/m/Y', strtotime($select_topup_row['topup_date'])); ?>" class="form-control" name="transfer_date" placeholder="วันที่โอนเงิน" />
                	<span class="input-group-addon add-on"><span class="glyphicon glyphicon-calendar"></span></span>
            	</div>
			</td>
			<th>เวลาที่โอน</th>
			<td>
				<div class="input-group input-append date" id="timePicker">
                	<input type="text" value="<?php echo date('G:i:s', strtotime($select_topup_row['topup_date'])); ?>" class="form-control" name="transfer_time" placeholder="เวลาที่โอนเงิน" 
                	onkeypress="return isTime(event)" />
                	<span class="input-group-addon add-on"><span class="glyphicon glyphicon-time"></span></span>
            	</div>
			</td>
		</tr>
		<tr>
			<th>ช่องทางการโอน</th>
			<td><input type="text" value="<?php echo $select_topup_row['transfer_method']; ?>" class="form-control" name="transfer_channel" placeholder="ช่องทางการโอนเงิน"></td>
		</tr>
		<tr>
			<th>หลักฐานการชำระเงิน</th>
			<td>
				<p>
					<?php
						if ($select_topup_row['bill_file_directory']!='') {
							echo "<img class='img img-thumbnail' src='".$select_topup_row['bill_file_directory']."' style='height:200px;'>";
						}
					?>
				</p>
				<input type="file" class="form-control" name="transfer_bill" id="transfer_bill">
			</td>
		</tr>
		<tr>
			<th>หมายเหตุ</th>
			<td><textarea placeholder="หมายเหตุ"  value="<?php echo $select_topup_row['customer_notes']; ?>"></textarea></td>
			<td colspan="2"><i class="material-icons">info</i> หลังจากท่านเติมเงินแล้ว กรุณาสั่งชำระเพื่อเป็นการยืนยันระบบจะได้ดำเนินการสั่งซื้อ หรือส่งสินค้า<br /> 
			<i class="material-icons">info</i>กรุณาแจ้งข้อมูล ยอดเงิน วันที่ ธนาคาร ให้ถูกต้องถ้าท่านแจ้งข้อมูลไม่ถูกต้องระบบ จะทำการยกเลิกให้ท่านตรวจสอบอีกครั้ง</td>
		</tr>
		<tr>
			<th></th>
			<td>
			<input type="hidden" name="topup_id" value="<?php echo $select_topup_row['topup_id'];?>">
			<button value="Submit" name="update-topup">อัพเดทข้อมูล</button>&emsp;<a href="topup_history.php">&#10094; กลับไปหน้าประวัติการเติมเงิน</a></td>
		</tr>
	</table>
	
	
	</form>

	<?php 
	}else{
		echo '<div class="alert alert-danger container" role="alert"><label>เกิดข้อผิดพลาด</label> : ไม่สามารถแก้ไขรายการนี้ได้</div>';
	}
	?>
</div>

<script>
$(document).ready(function() {
    $('#datePicker').datepicker({
            format: 'dd/mm/yyyy',
            todayHighlight: true
        })
        .on('changeDate', function(e) {
            // Revalidate the date field
            $('#eventForm').formValidation('revalidateField', 'transfer_date');
        });

});

function isNumber(evt) {
	//Enable arrow for firefox.
	if(navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
	    if (evt.keyCode == 8 || evt.keyCode == 46 || evt.keyCode == 37 || evt.keyCode == 39) {
		    return true;
		}
	}

    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;

    //Enable dot.
    if (charCode == 46) { return true; };

    if (charCode > 31 && (charCode < 48 || charCode > 57 )) {
        return false;
    }
    return true;
}

function isTime(evt) {
	//Enable arrow for firefox.
	if(navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
	    if (evt.keyCode == 8 || evt.keyCode == 46 || evt.keyCode == 37 || evt.keyCode == 39) {
		    return true;
		}
	}

    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;

    //Enable semicolon.
    if (charCode == 58) { return true; };

    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

</script>
	
</div>
        <?php include 'modal.php';  ?>
        <?php include 'footer.php';  ?>

        <script src="js/core.js"></script>
        <script type="text/javascript">

            function runScript(e) {
                if (e.keyCode == 13) {
                    searchURL();
                }
            }
        </script>
        <script src="dist/sweetalert.min.js"></script>
        <link rel="stylesheet" href="dist/sweetalert.css">
    </body>
</html>