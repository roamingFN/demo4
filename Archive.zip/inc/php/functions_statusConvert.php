<?php

function convertOrderStatus($status){
	$order_status_array = array();
	$query_order_status = mysql_query("select * from order_status_code");
	while ($row = mysql_fetch_array($query_order_status)) {
		$order_status_array[$row['status_id']]=$row['des'];
	}
	return $order_status_array[$status];
}
function convertPaymentStatus($status){
	switch ($status) {
		case '0':
			return "รอตรวจสอบยอด";
		case '1':
			return "ยอดไม่พอ";
		case '2':
			return "ดำเนินการแล้ว";
		default:
			return $status;
	}
}

function convertRequestType($status){
	switch ($status) {
		case '1':
			return "ค่าสินค้า";
		case '2':
			return "ค่าขนส่ง";
		default:
			return $status;
	}
}

function convertTopupStatus($status){
	switch ($status) {
		case '0':
			return "รอตรวจสอบ";
		case '1':
			return "ตรวจสอบแล้ว";
		case '2':
			return "ยกเลิก";
		default:
			return $status;
	}
}

function convertWithdarwStatus($status){
	switch ($status) {
		case '0':
			return "รอตรวจสอบ";
		case '1':
			return "ตรวจสอบแล้ว";
		case '2':
			return "ยกเลิก";
		default:
			return $status;
	}
}

function convertStatementZero($amout){
	if ($amout == 0) {
		return "-";
	}else{
		return $amout;
	}
}

function formatBankAccNo($acc_no){
		$acc_no = substr_replace($acc_no, '-', 3, 0);
		$acc_no = substr_replace($acc_no, '-', 5, 0);
		$acc_no = substr_replace($acc_no, '-', 11, 0);
		return $acc_no;
	}

function file_newname($path, $filename){
    if ($pos = strrpos($filename, '.')) {
           $name = substr($filename, 0, $pos);
           $ext = substr($filename, $pos);
    } else {
           $name = $filename;
    }

    $newpath = $path.'/'.$filename;
    $newname = $filename;
    $counter = 0;
    while (file_exists($newpath)) {
           $newname = $name .'_'. $counter . $ext;
           $newpath = $path.'/'.$newname;
           $counter++;
     }

    return $newpath;
}

function show_success($text){

	echo '<div class="alert alert-success container" role="alert"><label>'.$text.'</label></div>';

}

function show_error($text){

	echo '<div class="alert alert-danger container" role="alert"><label>'.$text.'</label></div>';

}

function show_info($text){

	echo '<div class="alert alert-info container" role="alert"><label>'.$text.'</label></div>';

}

function show_warning($text){

	echo '<div class="alert alert-warning container" role="alert"><label>'.$text.'</label></div>';

}

?>