<?php
	include 'connect.php';
	include 'session.php';
?>
<!DOCTYPE html>
<html>
  <head>
    <?php include 'page_script.php';  ?>
  </head>
  <body>
    <?php include 'nav_bar.php';  ?>
	<div class="content manage">
		<?php include 'left_menu.php' ?>
		<div class="menu-content col3">
			<br><table class="content-light center">
				<tr>
				<td class="selected"><i class="material-icons">check_circle</i><br>เลือกสินค้า</td><td>&#10095;</td>
				<td class="selected"><i class="material-icons">check_circle</i><br>สั่งซื้อสินค้า</td><td>&#10095;</td>
				<td><i class="material-icons">check_circle</i><br>สินค้ารอตรวจสอบ</td><td>&#10095;</td>
				<td><i class="material-icons">check_circle</i><br>สินค้ารอชำระเงิน</td><td>&#10095;</td>
				<td><i class="material-icons">check_circle</i><br>ส่งมอบสินค้า</td>
				</tr>
			</table>
		<h2>รายการสั่งซื้อสินค้า</h2>
<?php
	//ดึงข้อมูล rate & shipping rate
	$select_rate = mysql_query("select * from website_rate order by starting_date desc limit 1");
	$select_rate_row = mysql_fetch_array($select_rate);
	$rate_date = $select_rate_row['starting_date'];
	$rate = $select_rate_row['rate_cny'];
	$shipping_rate = $select_rate_row['shipping_rate_cny'];

	//start table
	$select_shop_group = mysql_query("select p.shop_name, p.source
										from product p, shopping_cart s
										where customer_id = '$user_id' 
										and s.product_id = p.product_id
										and s.selected = '1' 
										group by p.shop_name", $connection);

	if (mysql_num_rows($select_shop_group) > 0) {
		echo "<form action='order.php?action=submit_order' method='post' name='formCart' id='formCart'>";
		echo "<table class='content-grid'";
	        // our table heading
	        echo "<tr class='bg-primary'>";
	            echo "<th class='text-center'>ลำดับ</th>";
	            echo "<th colspan='2'>สินค้า</th>";
	            echo "<th class='text-center'>ราคา (หยวน)</th>";
	            echo "<th class='text-center'>จำนวน</th>";
	            echo "<th class='text-center'>ราคาทั้งหมด (หยวน)</th>";
	        echo "</tr>";

	    $sum_price = 0;
	    $sum_product = 0;
	    $sum_product_amount = 0;
	    $product_row = 1;

	    if (mysql_num_rows($select_shop_group)>0) {
			while ($shop_row = mysql_fetch_array($select_shop_group)) {
				$shop_name = $shop_row['shop_name'];
				
				echo "	<tr><td colspan='6' class='bg-info'>
							<strong> ชื่อร้าน: ".$shop_name.", </strong>
							<strong> เว็บไซต์: ".$shop_row['source']." </strong>
						</td></tr>";

				$select_item = mysql_query("select * from shopping_cart s, product p where customer_id = '$user_id' 
				and s.product_id=p.product_id and shop_name = '$shop_name' and selected = '1'", $connection);

				if(mysql_num_rows($select_item) > 0){ 
					$sum_product += mysql_num_rows($select_item);

			        while($row = mysql_fetch_array($select_item)) {
			 			$sum_price += $row['product_price']*$row['cart_quantity'];
			 			$sum_product_amount += $row['cart_quantity'];
			            //creating new table row per record
			            echo "<tr>";
			            	echo "<td class='text-center'>".$product_row."</td>";
			                echo "<td>";
			                	echo "<img style='width:50px;' class='img-thumbnail' src='".$row['product_img']."''>";
			                echo "</td>";
			                echo "<td>";
			                	echo "<a href='".$row['product_url']."' target='_blank'>".$row['product_name']."</a><br />";
			                	echo "ขนาด:".$row['product_size']."<br />";
			                	echo "สี:".$row['product_color']."";
			                echo "</td>";
			                echo "<td class='text-right'>";
			                	echo number_format($row['product_price'],2)." ¥";
			                echo "</td>";
			                echo "<td class='text-center'>";
			                	echo $row['cart_quantity'];
			                echo "</td>";
			                echo "<td class='text-right'>";
			                	echo number_format($row['product_price']*$row['cart_quantity'],2)." ¥";
			                echo "</td>";
			            echo "</tr>";
			            $product_row++;
			        }
				}
			}
		}
	            echo "
	            	  <tr>
	            	    <td colspan='6' class='bg-info'>&nbsp</td>
 					  </tr>
	            	  <tr>
	            	    <td>ยอดรวม</td>
	            	    <td>".$sum_product."</td>
	            	    <td>รายการ</td>
	            	    <td></td>
	            	    <td class='text-center'>".$sum_product_amount."</td>

	            	    <td></td>
 					  </tr>
	            	  <tr>
 					  </tr>
	            	  <tr>
	            		<td colspan='5' class='text-right'>ราคาสินค้ารวม (หยวน)</td>
	            		<td class='text-right'>". number_format($sum_price, 2)."</td>
	            	  </tr>	
	            	  <tr>
	            		<td colspan='5' class='text-right'>Rate @ ".$rate_date." (บาท)</td>
	            		<td class='text-right'> ". number_format($rate, 2)."</td>
	            	  </tr>	
	            	  <tr>
	            		<td colspan='5' class='text-right'>ราคาสินค้ารวม (บาท)</td>
	            		<td class='text-right'>". number_format($sum_price*$rate,2)."</td>
	            	  </tr>";
	 
	    echo 	"</table>";
	    echo 	"<input type='hidden' name='order_amount' value='".$sum_product_amount."'>";
	    echo 	"<h3>ข้อมูลการขนส่ง</h3>
	    	  	<div class='row col-md-12'>
	    	  		<div class='graybox'>
		    	  		<ul>
		    	  			<li>ขั้นตอนการชำระเงิน ลูกค้าจะต้องทำการชำระเงิน 2รอบ คือจ่ายค่าสินค้าและค่าขนส่งในจีน 									
 ส่วนค่าขนส่งจีน-ไทย และค่าขนส่งในไทย จะแจ้งเมื่อสินค้าเข้าโกดัง</li>
		    	  			<li> เพิ่มความรวดเร็วของสินค้า บริษัทส่งสินค้าจากจีนมาไทยด้วยวิธีรถด่วน เท่านั้น</li>
		    	  		</ul>
		    	  	</div>
	    	  		<h3>ขนส่งในไทยโดยใช้วิธี</h3>
	    	  		<div class='graybox'>
	    	  			<div class='form-group'>
			    	  		<div class='radio'>
							  	<label><input type='radio' name='opt_send' value='by_self' id='radio_by_self' >มารับเอง</label>
							</div>
						</div>
						<div class='form-group'>
							<div class='radio'>
							  	<label><input type='radio' name='opt_send' value='by_company' id='radio_by_company' checked>
							  	เลือกบรืษัทขนส่งในไทย</label>
							</div>

							<div id='opt_send_div' style='margin-left:50px;'>";

							$select_transport = mysql_query("select * from website_transport");
							$checked = "checked";
							while ($row = mysql_fetch_array($select_transport)) {
								echo "
								<div class='radio'>
								  	<label><input type='radio' name='opt_company' value='".$row['transport_eng_name']."' ".$checked." >".$row['transport_th_name']."</label>
								</div>
								";
								$checked = "";
							}

							echo "</div>
						</div>
					</div>
					<h3 id='address_head'>เลือกที่อยู่ส่งของ</h3>
					<div class='graybox' id='address_section'>
						<div class='form-group'>
							<div class='radio'>
							  	<label><input type='radio' name='opt_address' value='exist_address' checked>ที่อยู่ที่บันทึกไว้</label>
							</div>
							";
							$flag = 0;
							$exist_address = mysql_query("select * from customer_address where customer_id = '$user_id'");
							if (mysql_num_rows($exist_address) > 0) {
								while ($row = mysql_fetch_array($exist_address)) {
								echo "
								<div name='exist_address_div'  style='margin-left:50px;' class='well well-sm'>
								<input type='radio' name='exist_address_id' value='".$row['address_id']."' ";
								if($flag == 0){$flag = 1; echo "checked";}
								echo "
								> &nbsp&nbsp<strong>".$row['address_name']."</strong>
								<div class='box'>";
								echo $row['line_1']."<br />".$row['city'].", ".$row['country']."<br />".$row['zipcode']."<br />Tel. ".$row['phone']; 
							
								echo " 
								</div>
							</div>
							";
								}
								
							}else{
								echo "<div style='margin-left:50px;'><p>ยังไม่มีที่อยู่ที่บันทึกไว้<p></div>";
							}


						echo "<input type='hidden' id='address_count' value='".mysql_num_rows($exist_address) ."'
						</div>
						<div class='form-group'>
							<div class='radio'>
							  	<label><input type='radio' name='opt_address' value='new_address' id='create_new_address'>ที่อยู่ใหม่</label>
							</div>
						</div>
						<div class='row' id='new_address_div' style='margin-left:50px;'>
							<div class='form-horizontal'>
								<div class='form-group'>
									<div class='col-md-3'>
										<label>ชื่อผู้รับ </label>
									</div>
									<div class='col-md-8'>
										<input type='text' class='form-control' name='address_name' id='address_name'>
									</div>
								</div>
								<div class='form-group'>
									<div class='col-md-3'>
										<label>ที่อยู่</label>
									</div>
									<div class='col-md-8'>
										<input type='text' class='form-control' name='address_line1' id='address_line1'>
									</div>
								</div>
								<div class='form-group'>
									<div class='col-md-3'>
										<label>จังหวัด </label>
									</div>

									<div class='col-md-8'>
										<input type='text' class='form-control' name='address_city' id='address_city'>
									</div>
								</div>
								<div class='form-group'>
									<div class='col-md-3'>
										<label>ประเทศ </label>
									</div>
									<div class='col-md-8'>
										<input type='text' class='form-control' name='address_country' id='address_country'>
									</div>
								</div>
								<div class='form-group'>
									<div class='col-md-3'>
										<label>ไปรษณีย์ </label>
									</div>
									<div class='col-md-8'>
										<input type='text' class='form-control' name='address_zipcode' id='address_zipcode'>
									</div>
								</div>
								<div class='form-group'>
									<div class='col-md-3'>
										<label>โทรศัพท์ </label>
									</div>
									<div class='col-md-8'>
										<input type='text' class='form-control' name='address_tel' id='address_tel'>
									</div>
								</div>
							</div>
						</div>
					</div>
					<h3>หมายเหตุ</h3>
					<div class='form-group'>
						<textarea class='form-control' rows='3' cols='100' name='other_order_detail'></textarea>
					</div>
	    	  	</div>
	    	  	<h3 id='showmap'>แผนที่สำหรับมารับสินค้า</h3>
				<div class='graybox' id='showmap_section'>
					<img class='img img-thumbnail' src='http://www.swami.org.sg/images/map.gif'>
				</div>
	    ";
	    echo "<div class='row col-md-9' style='padding:30px;'>";
	    echo "<p style='color:red;'>โปรดตรวจสอบความถูกต้องของรายการสั่งซื้อทุกครั้ง ก่อนกดยืนยันการสั่งซื้อ</p><br /><br />";
	    echo "<a href='cart.php'>&#10094; แก้ไขรายการสั่งซื้อ</a>";
	    echo "<input type='submit' class='button' value='ยืนยันการสั่งซื้อ' onclick='return checkaddress()'>";
	    echo "</form>";
	    echo "</div>";
	}else{
		echo "error : ยังไม่มีรายการสินค้าในตะกร้า";
	}
?>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('#showmap').hide();
	    $('#showmap_section').hide();

		$("input[name=opt_send]:radio").change(function () {
			radio = document.getElementById('radio_by_self');
			if (radio.checked){
	            $('#opt_send_div').hide();
	            $('#address_head').hide();
	            $('#address_section').hide();
	            $('#showmap').show();
	            $('#showmap_section').show();
	        }else{
	        	$('#opt_send_div').show();
	        	$('#address_head').show();
	        	$('#address_section').show();
	            $('#showmap').hide();
	            $('#showmap_section').hide();
	        }
	    })

	    $('#new_address_div').hide();

	    $("input[name=opt_address]:radio").change(function () {
			radio = document.getElementById('create_new_address');
			if (radio.checked){
	            $('#new_address_div').show();
	            $("div[name='exist_address_div']").hide();
	        }else{
	        	$('#new_address_div').hide();
	        	$("div[name='exist_address_div']").show();
	        }
	    })
	});

	function checkaddress(){
		var radio_by_self = document.getElementById("radio_by_self");
		if (radio_by_self.checked) { return true; alert("by self"); }

		var address_count = document.getElementById("address_count").value;
		var address_name = document.getElementById("address_name").value;
		var address_line1 = document.getElementById("address_line1").value;
		var address_city = document.getElementById("address_city").value;
		var address_country = document.getElementById("address_country").value;
		var address_zipcode = document.getElementById("address_zipcode").value;
		var address_tel = document.getElementById("address_tel").value;
		var create_new = document.getElementById("create_new_address");

		if (Number(address_count) == 0) {
			if (create_new.checked) {
				if (address_name!="" && address_line1!="" && address_city!="" &&  address_country!="" && address_zipcode!="" && address_tel!="") {
					return true;
				}else{
					alert("กรุณากรอกข้อมูลที่อยู่ให้ครบทุกช่อง");
					return false;
				}
			}else{
				alert("กรุณาสร้างข้อมูลที่อยู่ใหม่");
				return false;
			}
		}else{
			if (create_new.checked) {
				if (address_name!="" && address_line1!="" && address_city!="" &&  address_country!="" && address_zipcode!="" && address_tel!="") {
					return true;
				}else{
					alert("กรุณากรอกข้อมูลที่อยู่ให้ครบทุกช่อง");
					return false;
				}
			}else{
				return true;
			}
		}

	}

</script>

        <?php include 'modal.php';  ?>
        <?php include 'footer.php';  ?>

        <script src="js/core.js"></script>
        <script type="text/javascript">

            function runScript(e) {
                if (e.keyCode == 13) {
                    searchURL();
                }
            }

        </script>
        <script src="dist/sweetalert.min.js"></script>
        <link rel="stylesheet" href="dist/sweetalert.css">
    </body>
</html>