<?php
$current_order_id = "";

	include 'connect.php';
	include 'session.php';

	if($action = isset($_GET['action']) && $_GET['action'] != ''){ 
		if ($action == 'submit_order') {

			$address_name = $_POST['address_name'];
			$address_line1 = $_POST['address_line1'];
			$address_city = $_POST['address_city'];
			$address_country = $_POST['address_country'];
			$address_zipcode = $_POST['address_zipcode'];
			$address_phone = $_POST['address_tel'];
			$address_id = '';
			$order_address_id = '';
			$order_amount = $_POST['order_amount'];
			$other_order_detail = $_POST['other_order_detail'];
			$order_transport_option = '';


			if (isset($_POST['exist_address_id'])) {
				$exist_address_id = $_POST['exist_address_id'];
			}

			
			//รับของด้วยตนเอง	
			if ($_POST['opt_send'] == 'by_self') {
				$order_transport_option = 'by_self';
			} //รับของกับบริษัทขนส่ง
			else if ($_POST['opt_send'] == 'by_company') {
				$order_transport_option = mysql_real_escape_string(stripcslashes($_POST['opt_company']));
				//เลือกที่อยู่เดิม
				if ($_POST['opt_address'] == 'exist_address') {
					$order_address_id = $exist_address_id;
				} //สร้างที่อยู่ใหม่
				else if ($_POST['opt_address'] == 'new_address') {
					$add_address = mysql_query("insert into customer_address(customer_id,address_name,line_1,city,country,zipcode,phone) 
						values('$user_id','$address_name','$address_line1','$address_city','$address_country','$address_zipcode','$address_phone')");
					if ($add_address) {
						$order_address_id = mysql_insert_id();
					}else {
						echo mysql_error();
					}
				}
			}

			//echo "order transport = ".$order_transport_option;

			//ดึงข้อมูล rate & shipping rate
			$select_rate = mysql_query("select * from website_rate order by starting_date desc limit 1");
			$select_rate_row = mysql_fetch_array($select_rate);
			$rate = $select_rate_row['rate_cny'];
			$shipping_rate = $select_rate_row['shipping_rate_cny'];

			//select last order number --(2)
			$select_order_number = mysql_query("SELECT order_number 
																					FROM customer_order 
																					WHERE YEAR(date_order_created) = '".date('Y')."' 
																					ORDER BY order_id DESC");

			//สร้าง order ใหม่ -- (1)
			$add_order =  mysql_query("insert into customer_order(customer_id, order_status_code, 
				product_quantity, order_price, order_rate, order_payment_flag, 
				order_shipping_payment_flag, order_address_id, date_order_created)
				values('$user_id', '0', '$order_amount', '0', '$rate', '0', '0', 
				'$order_address_id', NOW())");
			$order_id = mysql_insert_id();
			$current_order_id = $order_id;
			$add_order_shipping =  mysql_query("insert into customer_order_shipping (order_id, order_shipping_th_option, 
				order_shipping_th_ref_no, order_shipping_th_weight, order_shipping_th_cost, order_shipping_cn_cost)
				values ('$order_id', '$order_transport_option', '', '0', '0', '0')");

			//update order number -- (2)
			// echo "num row = ".mysql_num_rows($select_order_number);
			if (mysql_num_rows($select_order_number) > 0) {
				//เอา order_number เก่ามา +1
				$select_order_number_row = mysql_fetch_array($select_order_number);
				$old_order_number = $select_order_number_row[0];
				// echo "old_order_number=".$old_order_number;
				$number = (int)substr($old_order_number, 3);
				$order_number = "R".date("y").str_pad($number+1 ,7, "0", STR_PAD_LEFT);
				// echo "new_order_number=".$order_number;
				$update_number = mysql_query("update customer_order set order_number='$order_number' where order_id = '$order_id'");
			}else{
				//สร้าง order_number ใหม่
				$order_number = "R".date("y").str_pad(1 ,7, "0", STR_PAD_LEFT);
				// echo "create_new=".$order_number;
				$update_number = mysql_query("update customer_order set order_number='$order_number' where order_id = '$order_id'");
			}

			if($add_order && $add_order_shipping){ 

				//ย้ายสินค้าในตะกร้าไปใว้ใน customer_order_product
				$cart_item = mysql_query("select * from shopping_cart where customer_id='$user_id' and selected = '1'");
				while($row = mysql_fetch_array($cart_item)) {
					$cart_id = $row['cart_id'];
					$product_id = $row['product_id'];
					$cart_quantity = $row['cart_quantity'];
					$add_customers_order_product =  mysql_query("insert into customer_order_product(order_id,product_id,quantity) values($order_id,$product_id,$cart_quantity)");
					//ย้านเสร็จแล้วให้ลบสินค้าในตะกร้าทิ้ง
					if ($add_customers_order_product) {
						//echo "add product:".$product_id." into order:".$order_id." /";
						
						$delete_cart = mysql_query("delete from shopping_cart where cart_id = '$cart_id' and selected = '1'");
						if ($delete_cart) {
							//echo "[delete".$cart_id."] ";
						}
					}else{
						echo mysql_error();
					}
				}

			}else{
				echo mysql_error();
			}


			//########################
			//########################
			//update จำนวนร้านค้า จำนวนLink จำนวนสินค้า ยอดค่าสินค้า สถานะการสั่งซื้อ

			$total_shop = 0;
			$total_link = 0;
			$order_price_yuan = 0;
			$process_status = 0;

			$select_shop_group = mysql_query("	select shop_name
										from customer_order_product c, customer_order o, product p 
										where o.order_id = c.order_id 
										and c.product_id = p.product_id
										and o.customer_id = '$user_id'
										and o.order_id = '$current_order_id'
										group by p.shop_name", $connection);
			
			$total_shop = mysql_num_rows($select_shop_group);
	
			if (mysql_num_rows($select_shop_group) > 0) {
			    $sum_amount = 0;
			    $sum_price_cn = 0;
			    $sum_price_th = 0;
				while ($shop_row = mysql_fetch_array($select_shop_group)) {

					$shop_name = $shop_row['shop_name'];
					$select_item = mysql_query("select *
												from customer_order_product c, customer_order o, product p 
												where o.order_id = c.order_id 
												and c.product_id = p.product_id
												and o.customer_id = '$user_id'
												and o.order_id = '$current_order_id'
												and p.shop_name = '$shop_name'", $connection);

					if(mysql_num_rows($select_item) > 0){ 

					    
				        while($row = mysql_fetch_array($select_item)) {

				        	$sum_amount += $row['quantity'];
				        	$sum_price_cn += $row['product_price']*$row['quantity'];
				        	$sum_price_th += $row['product_price']*$row['quantity']*$row['order_rate'];

				        }
				    }
				}
			}

			$total_link = mysql_num_rows($cart_item);
			$order_price_yuan = $sum_price_cn;
			$process_status = 0;

			$update_order = mysql_query("update customer_order 
				set total_shop='$total_shop', total_link='$total_link', order_price='$sum_price_th', 
				order_price_yuan='$order_price_yuan', process_status='$process_status' 
				where order_id = '$current_order_id'");

			//end_update
			//########################
			//########################
		}
	}


?>
<html>
  <head>
    <?php include 'page_script.php';  ?>
  </head>
  <body>
    <?php include 'nav_bar.php';  ?>
	<div class="content manage">
		<?php include 'left_menu.php' ?>
		<div class="menu-content col3">
		<h2>สั่งซื้อสินค้าเรียบร้อย</h2>
		<h4>รายละเอียดการสั่งซื้อ</h4>
		<h4>หมายเลขการสั่งซื้อ : <?php echo $order_number; ?></h4>

	<?php
	$select_rate = mysql_query("select * from website_rate order by starting_date desc limit 1");
	$select_rate_row = mysql_fetch_array($select_rate);
	$rate_date = $select_rate_row['rate_date'];
	$rate = $select_rate_row['rate_cny'];
	$shipping_rate = $select_rate_row['shipping_rate_cny'];

	$select_shop_group = mysql_query("select p.shop_name, p.source
										from product p, customer_order_product cp, customer_order o 
										where o.customer_id = '$user_id' 
										and o.order_id = '$current_order_id'
										and o.order_id = cp.order_id
										and cp.product_id = p.product_id
										group by p.shop_name");

	if (mysql_num_rows($select_shop_group) > 0) {
		echo "<table class='content-grid'>";
	        echo "<tr class='bg-primary'>";
	            echo "<th class='text-center'>ลำดับ</th>";
	            echo "<th colspan='2'>สินค้า</th>";
	            echo "<th class='text-center'>จำนวน</th>";
	            echo "<th class='text-center'>ราคา (หยวน)</th>";
	            echo "<th class='text-center'>ราคาทั้งหมด (หยวน)</th>";
	        echo "</tr>";

	    $sum_price = 0;
	    $sum_product = 0;
	    $sum_product_amount = 0;
	    $product_row = 1;
		while ($shop_row = mysql_fetch_array($select_shop_group)) {
			$shop_name = $shop_row['shop_name'];
			
			echo "	<tr><td colspan='6' class='bg-info'>
						<strong> ชื่อร้าน: ".$shop_name.", </strong>cvb 
						<strong> เว็บไซต์: ".$shop_row['source']." </strong>
					</td></tr>";

			$select_item = mysql_query("select * from customer_order_product cp, product p, customer_order o 
				where o.customer_id = '$user_id' and o.order_id='$current_order_id' and o.order_id = cp.order_id
				and cp.product_id=p.product_id and p.shop_name = '$shop_name'", $connection);

			if(mysql_num_rows($select_item) > 0){ 
				$sum_product += mysql_num_rows($select_item);

		        while($row = mysql_fetch_array($select_item)) {
		 			$sum_price += $row['product_price']*$row['quantity'];
		 			$sum_product_amount += $row['quantity'];
		            //creating new table row per record
		            echo "<tr>";
		            	echo "<td class='text-center'>".$product_row."</td>";
		                echo "<td>";
		                	echo "<img style='width:50px;' class='img-thumbnail' src='".$row['product_img']."''>";
		                echo "</td>";
		                echo "<td>";
		                	echo "<a href='".$row['product_url']."' target='_blank'>".$row['product_name']."</a><br />";
		                	echo "ขนาด:".$row['product_size']."<br />";
		                	echo "สี:".$row['product_color']."";
		                echo "</td>";
		                echo "<td class='text-center'>";
		                	echo $row['quantity'];
		                echo "</td>";
		                echo "<td class='text-right'>";
		                	echo number_format($row['product_price'],2)." ¥";
		                echo "</td>";
		                echo "<td class='text-right'>";
		                	echo number_format($row['product_price']*$row['quantity'],2)." ¥";
		                echo "</td>";
		            echo "</tr>";
		            $product_row++;
		        }
			}
		}
	            echo "
	            	  <tr>
	            	    <td colspan='6' class='bg-info'>&nbsp</td>
 					  </tr>
	            	  <tr>
	            	    <td>ยอดรวม</td>
	            	    <td class='text-center'>".$sum_product."</td>
	            	    <td>รายการ</td>
	            	    <td class='text-center'>".$sum_product_amount."</td>
	            	    <td></td>
	            	    <td></td>
 					  </tr>
	            	  <tr>
 					  </tr>
	            	  <tr>
	            		<td colspan='4' class='text-right'>ราคาสินค้ารวม (CNY)</td>
	            		<td class='text-right'>". number_format($sum_price, 2)."</td>
	            		<td>หยวน</td>
	            	  </tr>	
	            	  <tr>
	            		<td colspan='4' class='text-right'>Rate @ ".$rate_date."</td>
	            		<td class='text-right'> ". number_format($rate, 2)."</td>
	            		<td>หยวน</td>
	            	  </tr>	
	            	  <tr>
	            		<td colspan='4' class='text-right'>ราคาสินค้ารวม (THB)</td>
	            		<td class='text-right'>". number_format($sum_price*$rate,2)."</td>
	            		<td>บาท</td>
	            	  </tr>
	            	";
	 				
	    echo 	"</table>";
	    $select_address = mysql_query("select * from customer_order c, customer_address a where c.order_id = '$current_order_id' and c.order_address_id = a.address_id");
	    $select_shopping_th_option = mysql_query("select * from customer_order_shipping s where s.order_id = '$current_order_id'");
	    if (mysql_num_rows($select_address) > 0) {
			$row_address = mysql_fetch_array($select_address);
			$row_shopping_th_option = mysql_fetch_array($select_shopping_th_option);

				echo "<h4>วิธีการจัดส่งสินค้าในไทย : ".$row_shopping_th_option['order_shipping_th_option']."</h4>";

				echo "<h4>ที่อยู่สำหรับจัดส่งสินค้า</h4>";
				echo "<div class='well'>";
				echo "<strong>ชื่อ ".$row_address['address_name']."</strong><br />";
				echo $row_address['line_1']."<br />".$row_address['city'].", ".$row_address['country']."<br />".$row_address['zipcode']."<br />Tel. ".$row_address['phone']; 
				echo "</div>";
			
			
		}
	}

	?>
		<hr>
		<p>ขณะนี้ออเดอร์อยู่ระหว่างการตรวจสอบและอัพเดทราคาโดยพนักงาน</p>
		<p>ท่านสามารถกดดูสถานะออร์เดอร์ได้จากเมนู "รายการสั่งซื้อ" ด้านมุมขวาบน</p><br /><br />
		<a href="order_list.php"><button>ไปยังหน้ารายการสั่งซื้อ</button></a><br /><br />
	</div>
</div>

<script type="text/javascript">
	
	// $(document).ready(function(){
    
	//   	$('#myTable').pageMe({pagerSelector:'#myPager',showPrevNext:true,hidePageNumbers:false,perPage:15});
	    
	// });
</script>


        <?php include 'modal.php';  ?>
        <?php include 'footer.php';  ?>

        <script src="js/core.js"></script>
        <script type="text/javascript">

            function runScript(e) {
                if (e.keyCode == 13) {
                    searchURL();
                }
            }

        </script>
        <script src="dist/sweetalert.min.js"></script>
        <link rel="stylesheet" href="dist/sweetalert.css">
    </body>
</html>