<?php 
$url = $_SERVER['REQUEST_URI'];
$tokens = explode('/', $url);
$path = $tokens[sizeof($tokens)-1];
?>
<div id="left_menu" class="menu-tab col4">
	<h3><i class="material-icons">assignment_ind</i> ข้อมูลลูกค้า</h3>
	<a href="profile.php" 			<?php if($path == "profile.php"){echo 'class="selected"';} ?> >ข้อมูลทั่วไป</a>
	<a href="change_password.php"	<?php if($path == "change_password.php"){echo 'class="selected"';} ?> >รหัสผ่าน</a>
	<a href="fav_shop.php"			<?php if($path == "fav_shop.php"){echo 'class="selected"';} ?> >ร้านค้าที่ชื่นชอบ</a>
	<div class="menu-line"></div>
	<h3><i class="material-icons">shopping_cart</i> สั่งซื้อ</h3>
	<a href="cart.php"				<?php if($path == "cart.php"){echo 'class="selected"';} ?> >ตะกร้า</a>
	<a href="order_list.php"		<?php if($path == "order_list.php"){echo 'class="selected"';} ?> >รายการสั่งซื้อ</a>
	<a href="payment_edit.php"		<?php if($path == "payment_edit.php"){echo 'class="selected"';} ?> >ตรวจสอบสถานะการชำระเงิน</a>
	<div class="menu-line"></div>
	<h3><i class="material-icons">assessment</i> บัญชี</h3>
	<a href="topup.php"				<?php if($path == "topup.php"){echo 'class="selected"';} ?> >เติมเงิน (แจ้งโอนเงิน)</a>
	<a href="payment.php"			<?php if($path == "payment.php"){echo 'class="selected"';} ?> >ชำระเงิน</a>
	<a href="statement.php"			<?php if($path == "statement.php"){echo 'class="selected"';} ?> >รายการบัญชีลูกค้า (statement)</a>
	<a href="topup_history.php"		<?php if($path == "topup_history.php"){echo 'class="selected"';} ?> >ประวัติการเติมเงิน</a>
	<a href="withdraw.php"			<?php if($path == "withdraw.php"){echo 'class="selected"';} ?> >แจ้งถอนเงิน</a>
	<a href="withdraw_history.php"	<?php if($path == "withdraw_history.php"){echo 'class="selected"';} ?> >ประวัติการแจ้งถอนเงิน</a>
	<div class="menu-line"></div>
	<h3><i class="material-icons">settings</i> ตั้งค่าการใช้งาน</h3>
	<a href="#">แก้ไขการรับข้อมูล<br>(ผ่านทาง email)</a>
	<br>
</div>
