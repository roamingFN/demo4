 <?php
	include 'connect.php';
	include 'session.php';
	include 'inc/php/functions_statusConvert.php';

$error = '';
if($action = isset($_GET['action']) && $_GET['action'] != ''){
	//create new topup requset
	if (!empty($_POST['topup-request-submit'])) {

		$topup_method 		= $_POST['topup_method'];
		$balance 			= $_POST['balance'];
		$transfer_date 		= $_POST['transfer_date'];
		$transfer_time 		= $_POST['transfer_time'];
		$transfer_channel 	= $_POST['transfer_channel'];
		$transfer_bill 		= $_FILES["transfer_bill"]["name"];
		$notes 				= $_POST['notes'];

		if(empty($topup_method)){ $error .= '<li>คุณยังไม่ได้เลือกบัญชีที่โอนเงินเข้า</li>';}
		if(empty($balance)){ $error .= '<li>คุณยังไม่ได้กรอกจำนวนเงิน</li>';}
		if(empty($transfer_date)){ $error .= '<li>คุณยังไม่ได้กรอกวันที่โอนเงิน</li>';}
		if(empty($transfer_time)){ $error .= '<li>คุณยังไม่ได้กรอกเวลาโอนเงิน</li>';}
		if(empty($transfer_channel)){ $error .= '<li>คุณยังไม่ได้กรอกช่องทางการโอนเงิน</li>';}

		$topup_method 		= stripcslashes($topup_method);
		$balance 			= stripcslashes($balance);
		$transfer_date 		= stripcslashes($transfer_date);
		$transfer_time 		= stripcslashes($transfer_time);
		$transfer_channel 	= stripcslashes($transfer_channel);
		$transfer_bill 		= stripcslashes($transfer_bill);
		$notes 				= stripcslashes($notes);

		$topup_method 		= mysql_real_escape_string($topup_method);
		$balance 			= mysql_real_escape_string($balance);
		$transfer_date 		= mysql_real_escape_string($transfer_date);
		$transfer_time 		= mysql_real_escape_string($transfer_time);
		$transfer_channel 	= mysql_real_escape_string($transfer_channel);
		$transfer_bill 		= mysql_real_escape_string($transfer_bill);
		$notes 				= mysql_real_escape_string($notes);

		$transfer_date = str_replace('/', '-', $transfer_date);
		$transfer_date = date('m/d/Y', strtotime($transfer_date));
		$transfer_datetime 	= $transfer_date." ".$transfer_time;
		//echo $transfer_datetime;

		if ($error == '') {

			if ($transfer_bill!=null) {

				$target_dir = "uploads/".$user_id;
				if (!is_dir($target_dir)&& strlen($target_dir)>0) {
					mkdir($target_dir, "0777");
					chmod($target_dir, 0777);
				}
				$target_file = $target_dir . basename($_FILES["transfer_bill"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				if(isset($_POST["topup-request-submit"])) {
				    $check = getimagesize($_FILES["transfer_bill"]["tmp_name"]);
				    if($check !== false) {
				        //echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				}
				// Check if file already exists
				$target_file = file_newname($target_dir,basename($_FILES["transfer_bill"]["name"]));

				// Check file size
				if ($_FILES["transfer_bill"]["size"] > 500000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["transfer_bill"]["tmp_name"], $target_file)) {
				        //echo "The file ". basename( $_FILES["transfer_bill"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}

				$add_topup_req = mysql_query("insert into customer_request_topup(customer_id,topup_bank,topup_amount,
					usable_amout,topup_status,topup_date,transfer_method,bill_file_directory,customer_notes)
					values('$user_id','$topup_method','$balance','$balance','0',STR_TO_DATE('$transfer_datetime','%c/%e/%Y %T'),
					'$transfer_channel','$target_file','$notes')");
				$topup_id = mysql_insert_id();
				$topup_number = "TU".date("y").str_pad($topup_id ,7, "0", STR_PAD_LEFT);
				$update_number = mysql_query("update customer_request_topup set topup_number='$topup_number' where topup_id = '$topup_id'");

				if ($add_topup_req) {
					echo '<div class="alert alert-success container" role="alert"><label>แจ้งข้อมูลการเติมเงินเรียบร้อย</label></div>';
				}else{
					echo '<div class="alert alert-danger container" role="alert">
					<label>เกิดข้อผิดพลาดในการบันทึกข้อมูล</label> โปรดตรวจสอบความถูกต้องของข้อมูลนำเข้า '.mysql_error().'</div>';
				}

			}else{

				//select last topup number --(2)
				$select_topup_number = mysql_query("SELECT topup_number 
																					FROM customer_request_topup 
																					WHERE YEAR(topup_date) = '".date('Y')."' 
																					ORDER BY topup_id DESC");

				//สร้าง topup ใหม่ --(1)
				$add_topup_req = mysql_query("insert into customer_request_topup(customer_id,topup_bank,topup_amount,
					usable_amout,topup_status,topup_date,transfer_method,customer_notes)
					values('$user_id','$topup_method','$balance','$balance','0',STR_TO_DATE('$transfer_datetime','%c/%e/%Y %T'),
					'$transfer_channel','$notes')");
				$topup_id = mysql_insert_id();

				//update topup number -- (2)
				// echo "num row = ".mysql_num_rows($select_topup_number);
				if (mysql_num_rows($select_topup_number) > 0) {
					//เอา order_number เก่ามา +1
					$select_topup_number_row = mysql_fetch_array($select_topup_number);
					$old_topup_number = $select_topup_number_row[0];
					// echo "old_topup_number=".$old_topup_number;
					$number = (int)substr($old_topup_number, 3);
					$topup_number = "R".date("y").str_pad($number+1 ,7, "0", STR_PAD_LEFT);
					// echo "new_topup_number=".$topup_number;
					$update_number = mysql_query("update customer_request_topup set topup_number='$topup_number' where topup_id = '$topup_id'");
				}else{
					//สร้าง topup_number ใหม่
					$topup_number = "R".date("y").str_pad(1 ,7, "0", STR_PAD_LEFT);
					// echo "create_new=".$topup_number;
					$update_number = mysql_query("update customer_request_topup set topup_number='$topup_number' where topup_id = '$topup_id'");
				}

				if ($add_topup_req) {
					echo '<div class="alert alert-success container" role="alert"><label>แจ้งข้อมูลการเติมเงินเรียบร้อย</label></div>';

					//clear data
					$_POST = array();
				}else{
					echo '<div class="alert alert-danger container" role="alert">
					<label>เกิดข้อผิดพลาดในการบันทึกข้อมูล</label> โปรดตรวจสอบความถูกต้องของข้อมูลนำเข้า '.mysql_error().'</div>';
				}
			}
		}else{

			echo '<div class="alert alert-danger container" role="alert"><label>เกิดข้อผิดพลาด</label>'.$error.'</div>';

		}
	}
}


?>
<!DOCTYPE html>
<html>
  <head>
    <?php include 'page_script.php';  ?>
    <style>
    	thead{
			color:#000;
		}
    </style>
  </head>
  <body>
    <?php include 'nav_bar.php';  ?>
	<div class="content manage">
		<?php include 'left_menu.php' ?>
		<div class="menu-content col3">

	<h1>เติมเงิน</h1>
	<i class="material-icons">info</i> เติมเงิน เป็นการเติมเงินเข้าระบบเท่านั้น ไม่ได้มีการตัดจ่ายบิลใดๆ หากลูกค้าต้องการชำระบิล กรุณา กดเมนู“ชำระเงิน”<br><br>
	</ul>
	<form role="form" action="topup.php?action=topup-request-submit" method="post" name="from_topup_req" 
		id="from_topup_req" enctype="multipart/form-data">
	<table class="content-grid">
		<tr>
			<th colspan="6" >เลือกบัญชีที่โอนเงินเข้า</th>
		</tr>

<?php 
$select_payment_method = mysql_query("select * from bank_payment");
if (mysql_num_rows($select_payment_method)>0) {
	while ($row = mysql_fetch_array($select_payment_method)) {
		echo "
		<tr>
			<td><input type='radio' name='topup_method' value='".$row['bank_id']."' ";
			if ($row['bank_id'] == $_POST['topup_method']) {
				echo " checked ";
			}
			echo" /></td>
			<td><img style='height:50px;' src='img/".$row['bank_img']."'></td>
			<td>".$row['bank_name_th']."</td>
			<td>".formatBankAccNo($row['account_no'])."</td>
			<td>".$row['account_name']."</td>
			<td>".$row['bank_branch']."</td>
		</tr>
		";
	}
}

?>


	</table>
	<br>
	<table class="content-light">
		<tr>
			<th>ยอดเงิน</th>
			<td><input type="text" class="form-control" placeholder="จำนวนเงินที่โอน" name="balance" id="balance" 
			onkeypress="return isNumber(event)" 
			value="<?php if (isset($_POST['balance'])) echo $_POST['balance']; ?>" /></td>
		</tr>
		<tr>
			<th>วันที่โอนเงิน</th>
			<td>
				<div class="input-group input-append date" id="datePicker">
                	<input type="text" class="form-control" name="transfer_date" placeholder="วันที่โอนเงิน" 
                		value="<?php if (isset($_POST['transfer_date'])) echo $_POST['transfer_date']; else echo date('d/m/Y'); ?>" />
                	<span class="input-group-addon add-on"><span class="glyphicon glyphicon-calendar"></span></span>
            	</div>
			</td>
			<th>เวลาที่โอน</th>
			<td>
				<div class="input-group input-append date" id="timePicker">
                	<input type="text" class="form-control" name="transfer_time" placeholder="เวลาที่โอนเงิน (ชั่วโมง:นาที)" 
                		onkeypress="return isTime(event)" 
                		value="<?php if (isset($_POST['transfer_time'])) echo $_POST['transfer_time']; ?>" />
                	<span class="input-group-addon add-on"><span class="glyphicon glyphicon-time"></span></span>
            	</div>
			</td>
		</tr>
		<tr>
			<th>ช่องทางการโอน</th>
			<td><input type="text" class="form-control" name="transfer_channel" placeholder="ช่องทางการโอนเงิน"
				value="<?php if (isset($_POST['transfer_channel'])) echo $_POST['transfer_channel']; ?>" ></td>
		</tr>
		<tr>
			<th>หลักฐานการชำระเงิน</th>
			<td><input type="file" class="form-control" name="transfer_bill" id="transfer_bill"></td>
		</tr>
		<tr>
			<th>หมายเหตุ</th>
			<td><textarea placeholder="หมายเหตุ" 
				value="<?php if (isset($_POST['notes'])) echo $_POST['notes']; ?>"></textarea></td>
			<td colspan="2"><i class="material-icons">info</i> หลังจากท่านเติมเงินแล้ว กรุณาสั่งชำระเพื่อเป็นการยืนยันระบบจะได้ดำเนินการสั่งซื้อ หรือส่งสินค้า<br /> 
			<i class="material-icons">info</i>กรุณาแจ้งข้อมูล ยอดเงิน วันที่ ธนาคาร ให้ถูกต้องถ้าท่านแจ้งข้อมูลไม่ถูกต้องระบบ จะทำการยกเลิกให้ท่านตรวจสอบอีกครั้ง</td>
		</tr>
		<tr>
			<th></th>
			<td><button type="submit" name="topup-request-submit" value="Submit">ตกลง</button>&emsp;<a href="topup_history.php">&#10094; แก้ไขการแจ้งโอนเงิน</a></td>
		</tr>
	</table>

	</form>

	</div></div><br /><br />

<script>
$("form").submit(function(){
    if (!$('[name="topup_method"]').is(':checked')){
    	swal('กรุณาเลือกบัญชีที่โอนเงินเข้าด้วยค่ะ');
       	$('html, body').animate({ scrollTop: 0 }, 'slow');
    	return false;
    }
    if($('[name="balance"]').val() == ''){
    	swal({   
    		title: 'กรุณากรอกจำนวนเงินที่โอนเข้าด้วยค่ะ',   
    	}, 
		function() {   
			$('html, body').animate({ scrollTop: $('[name="balance"]').offset().top-100 }, 'slow');
	       	$('[name="balance"]').focus();
		});
		return false;
   	}
   	if($('[name="transfer_date"]').val() == ''){
    	swal({   
    		title: 'กรุณากรอกวันที่โอนเงินด้วยค่ะ',   
    	}, 
		function() {   
			$('html, body').animate({ scrollTop: $('[name="transfer_date"]').offset().top-100 }, 'slow');
	       	$('[name="transfer_date"]').focus();
		});
		return false;
   	}
   	if($('[name="transfer_time"]').val() == ''){
    	swal({   
    		title: 'กรุณากรอกเวลาที่โอนเงินด้วยค่ะ',   
    	}, 
		function() {   
			$('html, body').animate({ scrollTop: $('[name="transfer_time"]').offset().top-100 }, 'slow');
	       	$('[name="transfer_time"]').focus();
		});
		return false;
   	}
   	if($('[name="transfer_channel"]').val() == ''){
    	swal({
    		title: 'กรุณากรอกช่องทางการโอนเงินด้วยค่ะ'
    	}, 
		function() {   
			$('html, body').animate({ scrollTop: $('[name="transfer_channel"]').offset().top-100 }, 'slow');
	       	$('[name="transfer_channel"]').focus();
		});
		return false;
   	}
});

$(document).ready(function() {
    $('#datePicker').datepicker({
            format: 'dd/mm/yyyy',
            endDate: '+07h',
            todayHighlight: true,
        	autoclose: true
        })
        .on('changeDate', function(e) {
            // Revalidate the date field
            $('#eventForm').formValidation('revalidateField', 'transfer_date');
        });
});



function isNumber(evt) {
	//Enable arrow for firefox.
	if(navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
	    if (evt.keyCode == 8 || evt.keyCode == 46 || evt.keyCode == 37 || evt.keyCode == 39) {
		    return true;
		}
	}

    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;

    //Enable dot.
    if (charCode == 46) { return true; };

    if (charCode > 31 && (charCode < 48 || charCode > 57 )) {
        return false;
    }
    return true;
}

function isTime(evt) {
	//Enable arrow for firefox.
	if(navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
	    if (evt.keyCode == 8 || evt.keyCode == 46 || evt.keyCode == 37 || evt.keyCode == 39) {
		    return true;
		}
	}

    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;

    //Enable semicolon.
    if (charCode == 58) { return true; };

    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

</script>
        <?php include 'modal.php';  ?>
        <?php include 'footer.php';  ?>

        <script src="js/core.js"></script>
        <script type="text/javascript">

            function runScript(e) {
                if (e.keyCode == 13) {
                    searchURL();
                }
            }

        </script>
        <script src="dist/sweetalert.min.js"></script>
        <link rel="stylesheet" href="dist/sweetalert.css">
    </body>
</html>

