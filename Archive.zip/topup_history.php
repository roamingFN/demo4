<?php
	include 'connect.php';
	include 'session.php';
	include 'inc/php/functions_statusConvert.php';
?>
<!DOCTYPE html>
<html>
  <head>
    <?php include 'page_script.php';  ?>
    <style>
    	thead{
			color:#000;
		}
    </style>
  </head>
  <body>
    <?php include 'nav_bar.php';  ?>
	<div class="content manage">
		<?php include 'left_menu.php' ?>
		<div class="menu-content col3">
	<h1>ประวัติการเติมเงิน</h1>

	<form role="form" method="post" action="topup_history.php?action=search">
		<table class="content-light">
			<tr>
				<td>วันที่</td>
				<td>
					<div class="input-group input-append date" id="datePicker" style="width:170px;">
		                <input type="text" class="form-control" name="topup_date" value="<?php //echo date("d/m/Y"); ?>" placeholder="วันที่แจ้งเติมเงิน" />
		                <span class="input-group-addon add-on"><span class="glyphicon glyphicon-calendar"></span></span>
		            </div>
				</td>
				<td>ธนาคาร</td>
				<td>
					<div class="form-group">
					  	<select class="form-control" name="bank_id">
					  		<option value="">ไม่เลือก</option>
					  	<?php 
					  		$select_bank = mysql_query("select * from bank_payment");
					  		if (mysql_num_rows($select_bank) > 0) {
					  			while($row = mysql_fetch_array($select_bank)){
					  				echo "<option value='".$row['bank_id']."'>".$row['bank_name_th']."</option>";
					  			}
					  		}

					  	?>

					  	</select>
					</div>
				</td>
				<td>เลขที่การเติมเงิน</td>
				<td><input type="text" name="topup_id" class="form-control" placeholder="เลขที่การเติมเงิน"></td>
				<td rowspan="2" class="text-center">
					<button type="submit" name="search" value="Submit" ><i class="material-icons">search</i></button><br><br>
					<a href="topup_history.php" class="button">แสดงทั้งหมด</a>

				</td>
			</tr>
			<tr>
				<td>ยอดเงิน</td>
				<td><input type="text" name="topup_amount" class="form-control" placeholder="จำนวนเงินที่โอน" onkeypress="return ((event.charCode >= 48 && event.charCode <= 57)||event.charCode == 46)"></td>
				<td>สถานะ</td> 
				<td>
					<div class="form-group">
					  	<select class="form-control" name="topup_status">
					  		<option value="">ไม่เลือก</option>
					  		<option value="0">รอตรวจสอบ</option>
					  		<option value="1">ตรวจสอบแล้ว</option>
					  		<option value="2">ยกเลิก</option>
					  	</select>
					</div>
				</td>
				<td>เลขที่บัญชี</td>
				<td>
					<div class="form-group">
					  	<select class="form-control" name="account_no">
					  		<option value="">ไม่เลือก</option>
					  	<?php 
					  		$select_bank = mysql_query("select * from bank_payment");
					  		if (mysql_num_rows($select_bank) > 0) {
					  			while($row = mysql_fetch_array($select_bank)){
					  				echo "<option value='".$row['account_no']."'>".$row['account_no']."</option>";
					  			}
					  		}

					  	?>

					  	</select>
					</div>
				</td>
				
			</tr>
		</table>
	</form>

	<?php

		$topup_date = '';
		$bank_id = '';
		$topup_id = '';
		$topup_amount = '';
		$topup_status = '';
		$account_no = '';

		if (isset($_POST['topup_date'])&& $_POST['topup_date']!="") 	{ 	
												$topup_date 	= $_POST['topup_date']; 
												$topup_date = str_replace('/', '-', $topup_date);
												$topup_date = date('m/d/Y', strtotime($topup_date));
											}
		if (isset($_POST['bank_id'])) 		{ $bank_id 		= $_POST['bank_id']; }
		if (isset($_POST['topup_id'])) 		{ $topup_id 	= $_POST['topup_id']; }
		if (isset($_POST['topup_amount'])) 	{ $topup_amount = $_POST['topup_amount']; }
		if (isset($_POST['topup_status'])) 	{ $topup_status	= $_POST['topup_status']; }
		if (isset($_POST['account_no'])) 	{ $account_no 	= $_POST['account_no']; }



		$query = "select * from customer_request_topup t, bank_payment b 
			where customer_id = '$user_id' and t.topup_bank = b.bank_id ";


		if( $topup_date != ''){ $query .= " and t.topup_date > STR_TO_DATE('$topup_date 00:00:00','%c/%e/%Y %T')  
			and t.topup_date < STR_TO_DATE('$topup_date 23:59:59','%c/%e/%Y %T')"; }
		if($bank_id != ''){ $query .= " and t.topup_bank = '$bank_id'"; } 
		if($topup_id != ''){ $query .= " and t.topup_number like '%$topup_id%'"; }
		if($topup_amount != ''){ $query .= " and t.topup_amount = '$topup_amount'"; }
		if($topup_status != ''){ $query .= " and t.topup_status = '$topup_status'"; }
		if($account_no != ''){ $query .= " and b.account_no = '$account_no'"; }

		$query .= " order by t.topup_date desc ";

		//echo $query;

		$topup = mysql_query($query);

		if (mysql_num_rows($topup) > 0) {
			echo '
		<form role="form">
		<table class="content-grid">
			<tr class="bg-primary">
				<th>วันที่โอน</th>
				<th>เวลา</th>
				<th>ยอดเงินที่เติม</th>
				<th>ยอดเงินที่ใช้ได้</th>
				<th>ช่องทาง</th>
				<th>ธนาคาร</th>
				<th>เลขบัญชี</th>
				<th>ชื่อบัญชี</th>
				<th>เลขที่การเติมเงิน</th>
				<th>สถานะยอดเงิน</th>
				<th>แก้ไข</th>
			</tr>
			';

			while ($row = mysql_fetch_array($topup)) {
				echo "
			<tr>
				<td>".date("d/m/Y", strtotime($row['topup_date']))."</td>
				<td>".date("G:i:s", strtotime($row['topup_date']))."</td>
				<td>".number_format($row['topup_amount'],2)."</td>
				<td>".number_format($row['usable_amout'],2)."</td>
				<td>".$row['transfer_method']."</td>
				<td><img style='height:50px' src='img/".$row['bank_img']."'>
				<input type='hidden' name='topup_bank' value='".$row['topup_bank']."'>
				</td>
				<td>".formatBankAccNo($row['account_no'])."</td>
				<td>".$row['account_name']."</td>
				<td>".$row['topup_number']."</td>
				<td>".convertTopupStatus($row['topup_status'])."</td>
				<td>";
				if ($row['topup_status']==0) {
					echo "<a href='topup_edit.php?topup_id=".$row['topup_id']."'><i class='material-icons'>edit</i></a>";
				}
				

				echo "</td>
			</tr>
			";
			}
		echo "
		</table>
		<br/><p>รายการทั้งหมด ".mysql_num_rows($topup) ." รายการ</p>
		";
		}else{
			echo "<div class='alert alert-danger'>ไม่พบข้อมูล</div>";
		}


	?>
		
		<br /><br /><p><i class="material-icons">info</i>ลูกค้าสามารถแก้ไข การแจ้งโอนเงินได้ในกรณีที่เป็นสถานะ "รอตรวจสอบ" เท่านั้น	</p>	
	</form>
	
</div>
	
</div><br /><br />
<script type="text/javascript">
	
$(document).ready(function() {
    $('#datePicker').datepicker({
            format: 'dd/mm/yyyy',
            todayHighlight: true
        })
        .on('changeDate', function(e) {
            // Revalidate the date field
            $('#eventForm').formValidation('revalidateField', 'transfer_date');
        });

});
</script>

        <?php include 'modal.php';  ?>
        <?php include 'footer.php';  ?>

        <script src="js/core.js"></script>
        <script type="text/javascript">

            function runScript(e) {
                if (e.keyCode == 13) {
                    searchURL();
                }
            }

        </script>
        <script src="dist/sweetalert.min.js"></script>
        <link rel="stylesheet" href="dist/sweetalert.css">
    </body>
</html>