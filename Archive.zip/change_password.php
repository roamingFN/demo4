<?php
	include 'connect.php';
	include 'session.php';

	$error = '';
	if (!empty($_POST['change_password_request'])) {

		$old_password 			= $_POST['old_password'];
		$new_password 			= $_POST['new_password'];
		$confirm_new_password 	= $_POST['confirm_new_password'];

		if(empty($old_password)){ $error .= '<li>คุณยังไม่ได้กรอกรหัสผ่านปัจจุบัน</li>';}
		if(empty($new_password)){ $error .= '<li>คุณยังไม่ได้กรอกรหัสผ่านใหม่</li>';}
		if(empty($confirm_new_password)){ $error .= '<li>คุณยังไม่ได้กรอกยืนยันรหัสผ่านใหม่</li>';}

		$old_password 			= stripcslashes($old_password);
		$new_password 			= stripcslashes($new_password);
		$confirm_new_password 	= stripcslashes($confirm_new_password);

		$old_password 			= mysql_real_escape_string($old_password);
		$new_password 			= mysql_real_escape_string($new_password);
		$confirm_new_password 	= mysql_real_escape_string($confirm_new_password);

		if ($error == '') {

			if ($new_password == $confirm_new_password) {
				$select_password = mysql_query("select passwd from customer where customer_id='$user_id'");
				$passwd = mysql_fetch_array($select_password);

				if (sha1($old_password) == $passwd['passwd']) {
					$pass = sha1($new_password);
					$update_passwd = mysql_query("update customer set passwd='$pass' where customer_id = '$user_id'");

					if($update_passwd) {
						echo '	<div class="alert alert-success container" role="alert"><label>
									Success, password changed
								</div>';
					}else{
						echo "fail".mysql_error();
					}
				}else{
					$error = '<li>รหัสผ่านปัจจุบันไม่ถูกต้อง</li>';
				}
			}else{
				$error = '<li>รหัสผ่านใหม่ไม่ตรงกัน</li>';
			}
		}

		if($error != ''){
			echo '<div class="alert alert-danger container" role="alert"><label>เกิดข้อผิดพลาด : </label>'.$error.'</div>';
		}
	}
?>
<!DOCTYPE html>
<html>
  <head>
    <?php include 'page_script.php';  ?>
  </head>
  <body>
    <?php include 'nav_bar.php';  ?>
	
	<div class="content manage">
		<?php include 'left_menu.php' ?>
		<div class="menu-content col3">
			<h1>เปลี่ยนรหัสผ่าน</h1>
			<form method="post" action="change_password.php" class="form-horizontal">

				<div class="form-group">
					<label for="old_password" class="col-md-3 control-label">รหัสผ่านปัจจุบัน</label>
	                <div class="col-md-8">
	                    <input type="text" class="form-control" name="old_password" id="old_password" >
	                </div>
	            </div>

                <div class="form-group">
					<label for="new_password" class="col-md-3 control-label">รหัสผ่านใหม่</label>
	                <div class="col-md-8">
	                    <input type="password" class="form-control" name="new_password" id="new_password" >
	                </div>
	            </div>

                <div class="form-group">
					<label for="confirm_new_password" class="col-md-3 control-label">ยืนยันรหัสผ่านใหม่</label>
	                <div class="col-md-8">
	                    <input type="password" class="form-control" name="confirm_new_password" id="confirm_new_password" >
	                </div>
	            </div>

                <div class="form-group">
                	<label for="email" class="col-md-3 control-label"></label>
	                <div class="col-md-8">
	                	<button type="submit" class="button" name="change_password_request" value="Submit">บันทึก</button>
	                </div>
                </div>

			</for

			m>
		</div>
	</div>

        <?php include 'modal.php';  ?>
        <?php include 'footer.php';  ?>

        <script src="js/core.js"></script>
        <script type="text/javascript">

            function runScript(e) {
                if (e.keyCode == 13) {
                    searchURL();
                }
            }

        </script>
        <script src="dist/sweetalert.min.js"></script>
        <link rel="stylesheet" href="dist/sweetalert.css">
    </body>
</html>

