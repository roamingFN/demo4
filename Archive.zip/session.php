<?php
	
	session_start();
	if (isset($_SESSION['CX_login_user'])) {
		// Storing Session
		$email_check = $_SESSION['CX_login_user'];
		// SQL Query To Fetch Complete Information Of User
		$ses_sql = mysql_query("select customer_email, customer_id from customer where customer_email='$email_check'", $connection);
		$row = mysql_fetch_assoc($ses_sql);
		$login_session =$row['customer_email'];
		$user_id =$row['customer_id'];
		
		if(!isset($login_session)){
			header('Location: index.php'); // Redirecting To Home Page
		}
	}else{
		header('Location: index.php'); // Redirecting To Home Page
	}


?>