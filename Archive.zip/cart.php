<?php
	include 'connect.php';
	include 'session.php';

	if(isset($_GET['action']) && $_GET['action'] != ''){

		//update product
		$action = $_GET['action'];

		if ($action == 'update' && isset($_POST['updatedata'])) {
			$cartId     = $_POST['hidCartId'];
			$productId  = $_POST['hidProductId'];
			$itemQty    = $_POST['txtQty'];
			$selected   = $_POST['selected'];
			$numItem    = count($itemQty);
			$numDeleted = 0;
			$notice     = '';
			$customer_id = $_SESSION['CX_login_id'];

			//reset product selected = 0
			$reset_selected = mysql_query("update shopping_cart set selected = 0 where customer_id = '$customer_id'", $connection);
			if(!empty($_POST['selected'])) {
			    foreach($_POST['selected'] as $check) {
			            $update_selected = mysql_query("update shopping_cart set selected = 1 where cart_id = '$check'", $connection);
			    }
			}
			
			for ($i = 0; $i < $numItem; $i++) {
				$newQty = (int)$itemQty[$i];
				// if ($newQty < 1) {
				// 	// remove this item from shopping cart
				// 	$customer_id = $_SESSION['CX_login_id'];
				// 	$delete_item = mysql_query("delete from shopping_cart 
				// 		where cart_id = '$cartId[$i]' and customer_id = '$customer_id'", $connection);

				// 	//update show cart amount
				// 	$cart_item = mysql_query("select count(product_id) from `shopping_cart` where customer_id = '$customer_id'", $connection);
				// 	$cart_item_row = mysql_fetch_array($cart_item);
				// 	setcookie('CX_cart_items', $cart_item_row['count(product_id)'], time() + (86400 * 30), "/");
				// 	header('Location: cart.php');			

				// 	$numDeleted += 1;
				// } else {
					// update product quantity
					$update_cart = mysql_query("update shopping_cart
							set cart_quantity = '$newQty'
							where cart_id = '$cartId[$i]'", $connection);
				//}
			}
			
			
		}

		//delete product
		if ($action == 'delete') {
			$delete_cartId = $_GET['cart_id'];
			$customer_id = $_SESSION['CX_login_id'];
			$delete_item = mysql_query("delete from shopping_cart 
				where cart_id = '$delete_cartId' and customer_id = '$customer_id'", $connection);

			//update show cart amount
			// $cart_item = mysql_query("select count(product_id) from `shopping_cart` where customer_id = '$customer_id'", $connection);
			// $cart_item_row = mysql_fetch_array($cart_item);
			// setcookie('CX_cart_items', $cart_item_row['count(product_id)'], time() + (86400 * 30), "/");
			// header('Location: cart.php');	
		}

		if ($action == 'update' && isset($_POST['submitdata'])) {
			$cartId     = $_POST['hidCartId'];
			$productId  = $_POST['hidProductId'];
			$itemQty    = $_POST['txtQty'];
			$selected   = $_POST['selected'];
			$numItem    = count($itemQty);
			$numDeleted = 0;
			$notice     = '';
			$customer_id = $_SESSION['CX_login_id'];

			//reset product selected = 0
			$reset_selected = mysql_query("update shopping_cart set selected = 0 where customer_id = '$customer_id'", $connection);
			if(!empty($_POST['selected'])) {
			    foreach($_POST['selected'] as $check) {
			            $update_selected = mysql_query("update shopping_cart set selected = 1 where cart_id = '$check'", $connection);
			    }
			}
			
			for ($i = 0; $i < $numItem; $i++) {
				$newQty = (int)$itemQty[$i];
				// if ($newQty < 1) {
				// 	// remove this item from shopping cart
				// 	$customer_id = $_SESSION['CX_login_id'];
				// 	$delete_item = mysql_query("delete from shopping_cart 
				// 		where cart_id = '$cartId[$i]' and customer_id = '$customer_id'", $connection);

				// 	//update show cart amount
				// 	$cart_item = mysql_query("select count(product_id) from `shopping_cart` where customer_id = '$customer_id'", $connection);
				// 	$cart_item_row = mysql_fetch_array($cart_item);
				// 	setcookie('CX_cart_items', $cart_item_row['count(product_id)'], time() + (86400 * 30), "/");
				// 	header('Location: cart.php');			

				// 	$numDeleted += 1;
				// } else {
					// update product quantity
					$update_cart = mysql_query("update shopping_cart
							set cart_quantity = '$newQty'
							where cart_id = '$cartId[$i]'", $connection);
				//}
			}
			header( "location: createorder.php" );
			
		}
	}

?>
<!DOCTYPE html>
<html>
  <head>
    <?php include 'page_script.php';  ?>
  </head>
  <body>
    <?php include 'nav_bar.php';  ?>
	<div class="content manage">
		<?php include 'left_menu.php' ?>
		<div class="menu-content col3">
			<br><table class="content-light center">
				<tr>
				<td class="selected"><i class="material-icons">check_circle</i><br>เลือกสินค้า</td><td>&#10095;</td>
				<td><i class="material-icons">check_circle</i><br>สั่งซื้อสินค้า</td><td>&#10095;</td>
				<td><i class="material-icons">check_circle</i><br>สินค้ารอตรวจสอบ</td><td>&#10095;</td>
				<td><i class="material-icons">check_circle</i><br>สินค้ารอชำระเงิน</td><td>&#10095;</td>
				<td><i class="material-icons">check_circle</i><br>ส่งมอบสินค้า</td>
				</tr>
			</table>
		<div class="content-line"></div>
		<h1>ตะกร้าสินค้า</h1>
			<form method="post" action="cart.php">
				<div class="form-inline">
					<label>ค้นหาสินค้า : </label>
					<input type="text" name="product_name" class="input" placeholder="คำค้นหา">
					<button style="border-width:0px;" type="submit" value="Submit"><i class="material-icons">search</i></button>
					<a href="cart.php" class="button" >แสดงทั้งหมด</a>
					<br><br>
				</div>
			</form>
<?php
	//ดึงข้อมูล rate & shipping rate
	$select_rate = mysql_query("select * from website_rate order by starting_date desc limit 1");
	$select_rate_row = mysql_fetch_array($select_rate);
	$rate = $select_rate_row['rate_cny'];
	$shipping_rate = $select_rate_row['shipping_rate_cny'];

	$query_status = "";
	if (isset($_POST['product_name'])) {
		$query_status .= " and p.product_name like '%".$_POST['product_name']."%' ";
	}

	//start table
	$select_shop_group = mysql_query("select p.shop_name, p.source
										from product p, shopping_cart s
										where customer_id = '$user_id' 
										and s.product_id=p.product_id ".$query_status." 
										group by p.shop_name", $connection);

	if (mysql_num_rows($select_shop_group) > 0) {
		echo "<form action='cart.php?action=update&cart_id=' method='post' name='formCart' id='formCart'>";
		echo "<table class='content-grid' id='cartTable'>";
	        // our table heading
	        echo "<thead>
	        	  <tr class='bg-primary'>";
	        	echo "<th colspan='3'>สินค้า 
 						<input type='checkbox' onClick='toggle(this)'  name='checkall'/> เลือกทั้งหมด<br/>
	        	      </th>";
	            echo "<th class='text-center'>ราคา (หยวน)</th>";
	            echo "<th class='text-center'>จำนวน</th>";
	            echo "<th class='text-center'>ราคารวม (หยวน)</th>";
	            echo "<th class='text-center'>ตัวเลือก</th>";
	        echo "</tr>
	              </thead>
				  <tbody id='myTable'>";

	    $sum_price = 0;
		while ($shop_row = mysql_fetch_array($select_shop_group)) {
			$shop_name = $shop_row['shop_name'];
			
			echo "	<tr><td colspan='7' class='bg-info'>
						<strong> ชื่อร้าน: ".$shop_name.", </strong>
						<strong> เว็บไซต์: ".$shop_row['source']." </strong>
					</td></tr>";

			$select_item = mysql_query("select * from shopping_cart s, product p where customer_id = '$user_id' 
			and s.product_id=p.product_id and shop_name = '$shop_name' ".$query_status." ", $connection);

			if(mysql_num_rows($select_item) > 0){ 
			    
			        while($row = mysql_fetch_array($select_item)) {
			 			if($row['selected']=='1'){ $sum_price += $row['product_price']*$row['cart_quantity']; }
			            //creating new table row per record
			            echo "<tr>";
			            	echo "<td class='text-center'><input type='checkbox' id='selected' name='selected[]' value='".$row['cart_id']."'"; if($row['selected']=='1'){ echo "checked";} echo "></td>";
			                echo "<td>";
			                	echo "<a href='".$row['product_img']."' data-lightbox='preview_img'><img style='min-width:50px;height:50px;' class='img-thumbnail' src='".$row['product_img']."''></a>";
			                echo "</td>";
			                echo "<td style='min-width:300px;'>";
			                	echo "<a href='".$row['product_url']."' target='_blank'>".$row['product_name']."</a><br />";
			                	echo "ขนาด:".$row['product_size']."<br />";
			                	echo "สี:".$row['product_color']."";
			                echo "</td>";
			                echo "<td class='text-right'>";
			                	echo number_format($row['product_price'],2)." ¥";
			                echo "</td>";
			                echo "<td class='text-right'>";
			                	echo "	<input name='txtQty[]' id='txtQty[]' type='text' size='3' value='".$row['cart_quantity']."' onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
			                			<input name='hidCartId[]' type='hidden' value='".$row['cart_id']."'>
			                			<input name='hidProductId[]' type='hidden' value='".$row['product_id']."'>";
			                echo "</td>";
			                echo "<td class='text-right'>";
			                	echo "<span name='item_price' data-price='".$row['product_price']*$row['cart_quantity']."' >".number_format($row['product_price']*$row['cart_quantity'],2)."</span> ¥";
			                echo "</td>";
			                echo "<td>";

			                    echo "<a href='cart.php?action=delete&cart_id=".$row['cart_id']."' class='delete' onclick='return confirm_remove()'>";
			                        echo "✖";
			                    echo "</a>";
			                echo "</td>";
			            echo "</tr>";
			        }
			            
			}
		}
		echo "</tbody>
				<tr>
        			<th colspan='5' class='text-right'>ราคาทั้งหมด</td>
        			<th class='text-right'><span id='total_price' >". number_format($sum_price,2)."</span></td>
        			<th>หยวน</td>
        	  	</tr>";
		echo "
			  </table><br />
			  <p>ทั้งหมด : <span id='select_amount'></span> | <input type='checkbox' name='checkall' onClick='toggle(this)'/> เลือกทั้งหมด</p>
			  <div class='col-md-12 text-center'>
      				<ul class='pagination pagination-lg pager' id='myPager'></ul>
     			</div>";
		echo "<hr><hr><hr>";
        //echo "<input class='btn btn-info' type='submit' value='Update' name='updatedata'>";
        //echo "(กด update ทุกครั้งเมื่อเปลี่ยนแปลงข้อมูล)<br /><br /> ";
	    echo "<button type='submit' name='submitdata' value='Submit' onclick='return checkpricezero();' ><i class='material-icons'>shopping_cart</i><h3>สั่งซื้อ</h3></button>";
	    echo "</form><br /><hr /><p><i class='material-icons'>info</i> 1 บิล สามารถเพิ่มรายการสินค้าได้สูงสุด 50 รายการเท่านั้น</p>";

	}else
	{
		echo "ยังไม่มีรายการสินค้าในตะกร้า";
		$emthycart = 1;
	}  

?>
	</div>
	</div>

<?php if($emthycart != 1){ ?>
<script type="text/javascript">
	
	function checkpricezero(){

		// var price = document.getElementById('total_price').innerText;
		// if (price != "0.00") {
			
		// }else{
		// 	alert("กรุณาเลือกรายการสินค้าอย่างน้อย 1 รายการ");
		// 	return false;
		// }
		// return false;

		var count_box = 0;
       	checkboxes = document.getElementsByName('selected[]');
		for(var i=0, n=checkboxes.length;i<n;i++) {
		    if(checkboxes[i].checked){
		    	count_box++;
		    }
		}
		if (count_box == 0) {
			return false;
			alert("กรุณาเลือกรายการสินค้าอย่างน้อย 1 รายการ");
		}else{
			return true;
		}

	}

	function confirm_remove(){

		var r = confirm("Do you want to remove this product");
		return r;
	}

	function toggle(source) {
		checkboxes = document.getElementsByName('selected[]');
		for(var i=0, n=checkboxes.length;i<n;i++) {
		    checkboxes[i].checked = source.checked;
		}

		checkall = document.getElementsByName('checkall');
		for(var i=0, n=checkall.length;i<n;i++) {
		    checkall[i].checked = source.checked;
		}

		var count_box = 0;
		var sum_price = 0;
	       	checkboxes = document.getElementsByName('selected[]');
	       	//item_price = document.getElementsByName('item_price[]');
	       	var array = [];
			$('span[name=item_price]').each(function () {
			    array.push(this.getAttribute("data-price"));
			});
			//alert(array);

			for(var i=0, n=checkboxes.length;i<n;i++) {
			    if(checkboxes[i].checked){
			    	count_box++;
			    	//var x = item_price[i].getAttribute("data-price");
			    	//alert(item_price[0].innerHTML);
			    	sum_price += parseFloat(array[i]);
			    }
			}
		document.getElementById('select_amount').innerText = count_box;
		document.getElementById('total_price').innerText = sum_price.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');;

		// var count_box = 0;
	 //       	checkboxes = document.getElementsByName('selected[]');
		// 	for(var i=0, n=checkboxes.length;i<n;i++) {
		// 	    if(checkboxes[i].checked){
		// 	    	count_box++;
		// 	    }
		// 	}
		// document.getElementById('select_amount').innerText = count_box;
	}

	$(document).ready(function(){

	  	$('#myTable').pageMe({pagerSelector:'#myPager',showPrevNext:true,hidePageNumbers:false,perPage:15});
    	
    	// $('#cartTable thead th').each( function () {
     //    var title = $('#cartTable tfoot th').eq( $(this).index() ).text();
     //    $(this).html( '<input type="text" placeholder="Search '+title+'" class="form-control" />' );
    	// } );

	  	//var table = $('#cartTable').DataTable();

	  	// Apply the search
	    // table.columns().every( function () {
	    //     var that = this;
	 
	    //     $( 'input', this.footer() ).on( 'keyup change', function () {
	    //         if ( that.search() !== this.value ) {
	    //             that
	    //                 .search( this.value )
	    //                 .draw();
	    //         }
	    //     } );
	    // } );
	    
	});

	$(document).ready(function() {
			var count_box = 0;
			var sum_price = 0;
	       	checkboxes = document.getElementsByName('selected[]');
	       	var array = [];
			$('span[name=item_price]').each(function () {
			    array.push(this.getAttribute("data-price"));
			});
			for(var i=0, n=checkboxes.length;i<n;i++) {
			    if(checkboxes[i].checked){
			    	count_box++;
			    	sum_price += parseFloat(array[i]);
			    }
			}
			document.getElementById('select_amount').innerText = count_box;
			document.getElementById('total_price').innerText = sum_price.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');;
			
	});

	$(document).ready(function() {
	    $('input:checkbox').change(function() {
			var count_box = 0;
			var sum_price = 0;
	       	checkboxes = document.getElementsByName('selected[]');

	       	var array = [];
			$('span[name=item_price]').each(function () {
			    array.push(this.getAttribute("data-price"));
			});
	       	//var item_price = document.getElementsByName('item_price[]');
	       	//if (item_price == null) { alert("null")};
			for(var i=0, n=checkboxes.length;i<n;i++) {
			    if(checkboxes[i].checked){
			    	count_box++;
			    	sum_price += parseFloat(array[i]);
			    }
			}
			document.getElementById('select_amount').innerText = count_box;
			document.getElementById('total_price').innerText = sum_price.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');;
			
			
			// for(var i=0, n=item_price.length;i<n;i++) {
			//     sum_price += Number(item_price[i].innerText);
			// }
			// sum_price = 100;
			//document.getElementById('total_price').innerText = sum_price;
	    });
	});

</script>
<?php } ?>

        <?php include 'modal.php';  ?>
        <?php include 'footer.php';  ?>

        <script src="js/core.js"></script>
        <script type="text/javascript">

            function runScript(e) {
                if (e.keyCode == 13) {
                    searchURL();
                }
            }

        </script>
        <script src="dist/sweetalert.min.js"></script>
        <link rel="stylesheet" href="dist/sweetalert.css">
    </body>
</html>


