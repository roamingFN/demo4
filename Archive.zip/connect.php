<?php
//Connect XAMPP
$connection = mysql_connect("localhost", "root", "");
mysql_query("SET NAMES UTF8",$connection);	
$db = mysql_select_db("china_express", $connection);

//Connect HOST
// $connection = mysql_connect("localhost", "narutoro", "Zdj32g6iY8");
// $db = mysql_select_db("narutoro_CX", $connection);

?>