<div class="footer">
    <div class="wrapper">
        <div class="inner">
            <div class="col4">
                <a href="index.php">หน้าแรก</a>
                <a href="#">วิธีการใช้งาน</a>
                <a href="how_to_payment.php">วิธีการชำระเงิน &ค่าขนส่ง</a>
                <a href="rate.php">อัตราแลกเปลี่ยนย้อนหลัง</a>
            </div>
            <div class="col4">
                <a href="suggestion.php">แนะนำร้าน</a>
                <a href="faq.php">ถาม-ตอบ</a>
                <a href="about.php">เกี่ยวกับเรา</a>
                <a href="contact.php">ติดต่อเรา</a>
            </div>
            <div class="col4">
                <p><i class="material-icons">home</i> 22/3 หมู่ที1   ตำบล ท่าอิฐ   อำเภอ ปากเกร็ด  จังหวัด นนทบุรี  11120</p>
            </div>
            <div class="col4">
                <p><i class="material-icons">phone</i> มือถือ: 089-052-8899<br>&emsp;&nbsp;&nbsp;Office: 02-924-5850 </p>
                <p><i class="material-icons">email</i> cs@order2you.com</p>
            </div>
            <p class="copyright">Order2Easy © 2015</p>
        </div>
    </div>
</div>