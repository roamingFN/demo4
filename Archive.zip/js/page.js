
	function checkLogin() {

		var flag=0;

	    var email = document.getElementById('login-email');
	    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

	    if (!filter.test(email.value)) {
	    	document.getElementById('help-login-email').innerText = "กรุณากรอกอีเมล์ให้ถูกต้อง";
	    	email.focus;
	    	flag = 1;
	 	}

	 	if (document.getElementById('login-password').value == "") {
	 		document.getElementById('help-login-password').innerText = "กรุณากรอกรหัสผ่าน";
	 		flag = 1;
	 	}else{
	 		document.getElementById('help-login-password').innerText = "";
	 	}

	 	if (flag == 1) {return false;};
	}

	function validateRegisterForm(){

		var flag=0;

		var email = document.getElementById('register-email');
	    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

	    if (!filter.test(email.value)) {
	    	document.getElementById('help-register-email').innerText = "กรุณากรอกอีเมล์ให้ถูกต้อง";
	    	flag = 1;
	 	}else{

	 		if (document.getElementById('help-register-email').innerText == "อีเมล์นี้ถูกใช้งานไปแล้ว!") {
	 			flag = 1;
	 		}else{   
	 			document.getElementById('help-register-email').innerText = "";
	 		}
	 	}

	 	if (document.getElementById('register-password').value == "") {
	 		document.getElementById('help-register-password').innerText = "กรุณากรอกรหัสผ่าน";
	 		flag = 1;
	 	}else{
	 		document.getElementById('help-register-password').innerText = "";
	 	}

	 	if (document.getElementById('register-firstname').value == "") {
	 		document.getElementById('help-register-firstname').innerText = "กรุณากรอกชื่อ";
	 		flag = 1;
	 	}else{
	 		document.getElementById('help-register-firstname').innerText = "";
	 	}

	 	if (document.getElementById('register-lastname').value == "") {
	 		document.getElementById('help-register-lastname').innerText = "กรุณากรอกนามสกุล";
	 		flag = 1;
	 	}else{
	 		document.getElementById('help-register-lastname').innerText = "";
	 	}

	 	if (document.getElementById('register-phone').value == "") {
	 		document.getElementById('help-register-phone').innerText = "กรุณากรอกเบอร์โทรศัพท์";
	 		flag = 1;
	 	}else{
	 		document.getElementById('help-register-phone').innerText = "";
	 	}



	 	if (flag == 1) {return false;};
	}

	$(document).ready(function(){
		$("#register-email").blur(function()
	        {
	            $.ajax({
	                type: "POST",
	                data: {
	                    email: $('#register-email').val(),
	                },
	                url: "emailexists.php",
	                success: function(data)
	                {
	                    if(data === 'USER_EXISTS')
	                    {
	                        $('#help-register-email')
	                            .css('color', 'red')
	                            .html("อีเมล์นี้ถูกใช้งานไปแล้ว!");
	                    }
	                    else if(data === 'USER_AVAILABLE')
	                    {
	                    	if ($('#register-email').val() == "") {
	                    		$('#help-register-email')
		                            .html("กรุณากรอกอีเมล์");
	                    	}else{ 
		                        $('#help-register-email')
		                            .css('color', 'green')
		                            .html("ท่านสามารถใช้งานอีเมล์นี้ได้");
	                        }
	                    }
	                }
	            })              
	        }
	    )

	});

	function searchURL(){

		$('#search_mdl').modal('show');
		var req;
		if (window.XMLHttpRequest) {
			req = new XMLHttpRequest();
		}
		else if (window.ActiveXObject) {
			req = new ActiveXObject("Microsoft.XMLHTTP"); 
		}
		else{
			alert("Browser error");
			return false;
		}
		req.onreadystatechange = function()
		{
			if (req.readyState == 4) {
				var resultarea = document.getElementById('show_search_result');
				resultarea.innerHTML = req.responseText;
			}
			else
			{
				var resultarea = document.getElementById('show_search_result');
				resultarea.innerHTML = "<center><img src=progress_bar.gif><br /><br /><small>การรวบรวมข้อมูลอาจใช้เวลาสักระยะ หากข้อมูลสินค้ามีจำนวนมาก</small></center>";

			}
		}
		var searchValue = document.getElementById('searchText').value;

		req.open("GET", "grab2.php?url="+encodeURIComponent(searchValue), true);	// ส่งค่าไปประมวลผลที่ไฟล์ sql.php
		req.send(null); 


		// Timeout to abort in 10 seconds
		// var xmlHttpTimeout=setTimeout(ajaxTimeout,30000);
		// function ajaxTimeout(){
  //  			req.abort();
  //  			alert("Request timed out");
		// }

	}

	function clearURL(){
		document.getElementById('searchText').value = "";
	}

	function itemURL(url){
		$('#search_mdl').modal('show');
		var req;
		if (window.XMLHttpRequest) {
			req = new XMLHttpRequest();
		}
		else if (window.ActiveXObject) {
			req = new ActiveXObject("Microsoft.XMLHTTP"); 
		}
		else{
			alert("Browser error");
			return false;
		}
		req.onreadystatechange = function()
		{
			if (req.readyState == 4) {
				var resultarea = document.getElementById('show_search_result');
				resultarea.innerHTML = req.responseText;
			}
			else
			{
				var resultarea = document.getElementById('show_search_result');
				resultarea.innerHTML = "<center><img src=progress_bar.gif><br /><br /><small>การรวบรวมข้อมูลอาจใช้เวลาสักระยะ หากข้อมูลสินค้ามีจำนวนมาก</small></center>";

			}
		}

		//alert(url);
		var searchValue =  decodeURIComponent(url);
		//alert(searchValue);

		req.open("GET", "grab2.php?url="+encodeURIComponent(url), true);	// ส่งค่าไปประมวลผลที่ไฟล์ sql.php
		req.send(null); 
		// Timeout to abort in 10 seconds
		// var xmlHttpTimeout=setTimeout(ajaxTimeout,30000);
		// function ajaxTimeout(){
  //  			req.abort();
  //  			alert("Request timed out");
		// }

	}

	function manualAdd(){
		$('#manualadd').modal('show');
		var resultarea = document.getElementById('show_manualadd');
		//resultarea.innerHTML = "req.responseText";
	}


	function addtocart(){
		var product_url = document.getElementById('product_url').innerHTML;
		var product_img = document.getElementById('product_img').src;
		var product_name = document.getElementById('product_name').innerHTML;
		var product_price = document.getElementById('product_price').innerHTML;
		var product_size = $('input[id=product_size]:checked').val();
		var product_color = $('input[id=product_color]:checked').val();
		var product_quentity = document.getElementById('product_amount').value;
		var shop_name = document.getElementById('shop_name').value;
		var source = document.getElementById('source').value;

		if (document.getElementById('product_size')!= null) {
			if (typeof product_size == 'undefined') { 
			document.getElementById('alert-size').innerText = 'Please select size';
			document.getElementById('alert-size').style.color = 'red';
			return false; 
			}
		}else{
			product_size = 'No Size';
		}
		
		if (document.getElementById('product_color')!= null) {
			if (typeof product_color == 'undefined') { 
				document.getElementById('alert-color').innerText = 'Please select color';
				document.getElementById('alert-color').style.color = 'red';
				return false; 
			}
		}else{
			product_color = 'No Color';
		}

		$('#search_mdl').modal('hide');
		$('#addtocart').modal('show');
		var req;
		if (window.XMLHttpRequest) {
			req = new XMLHttpRequest();
		}
		else if (window.ActiveXObject) {
			req = new ActiveXObject("Microsoft.XMLHTTP"); 
		}
		else{
			alert("Browser error");
			return false;
		}
		req.onreadystatechange = function()
		{
			if (req.readyState == 4) {
				var resultarea = document.getElementById('show_addtocart_result');
				resultarea.innerHTML = req.responseText;
			}
			else
			{
				var resultarea = document.getElementById('show_addtocart_result');
				resultarea.innerHTML = "<img src=progress_bar.gif>";

			}
		}

		req.open("POST","addtocart.php",true);
		req.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		req.send("product_url="+product_url+"&product_img="+product_img+"&product_name="+product_name+
			"&product_price="+product_price+"&product_size="+product_size+"&product_color="+product_color+
			"&product_quentity="+product_quentity+"&shop_name="+shop_name+"&source="+source);
	}

	function manual_addtocart(){

		var product_url = document.getElementById('mproduct_url').value;
		var product_img = document.getElementById('mproduct_img').value;
		var product_name = document.getElementById('mproduct_name').value;
		var product_price = document.getElementById('mproduct_price').value;
		var product_size = document.getElementById('mproduct_size').value;
		var product_color = document.getElementById('mproduct_color').value;
		var product_quentity = document.getElementById('mproduct_quantity').value;
		var shop_name = document.getElementById('mshop_name').value;
		var source = document.getElementById('msource').value;

		if (product_url== '') {
			alert('กรุณาใส่ ลิงค์เว็บไซด์');
			return false;
		}
		if (product_name== '') {
			alert('กรุณาใส่ ชื่อสินค้า');
			return false;
		}
		if (product_img == '') {product_img = 'img/x6.png';};
		if (shop_name == '') {shop_name = 'ไม่ระบุ';};
		if (product_size == '') {product_size = 'No Size';};
		if (product_color == '') {product_color = 'No Color';};
		if (product_price== '') {
			alert('กรุณาใส่ ราคา');
			return false;
		}
		if (product_quentity== '') {
			alert('กรุณาใส่ จำนวน');
			return false;
		}

		$('#manualadd').modal('hide');
		$('#addtocart').modal('show');
		var req;
		if (window.XMLHttpRequest) {
			req = new XMLHttpRequest();
		}
		else if (window.ActiveXObject) {
			req = new ActiveXObject("Microsoft.XMLHTTP"); 
		}
		else{
			alert("Browser error");
			return false;
		}
		req.onreadystatechange = function()
		{
			if (req.readyState == 4) {

				var resultarea = document.getElementById('show_addtocart_result');
				resultarea.innerHTML = req.responseText;
			}
			else
			{
				var resultarea = document.getElementById('show_addtocart_result');
				resultarea.innerHTML = "<img src=progress_bar.gif>";

			}
		}

		req.open("POST","addtocart.php",true);
		req.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		req.send("product_url="+product_url+"&product_img="+product_img+"&product_name="+product_name+
			"&product_price="+product_price+"&product_size="+product_size+"&product_color="+product_color+
			"&product_quentity="+product_quentity+"&shop_name="+shop_name+"&source="+source);
	}

	function qtyplus(){
		var amout = document.getElementById('product_amount').value;
		var currentVal = parseInt(amout);
		if (!isNaN(currentVal)) {
			document.getElementById('product_amount').value = currentVal+1;
		}else {
            // Otherwise put a 0 there
            document.getElementById('product_amount').value = 0;
        }
		
	}

	function qtyminus(){
		var amout = document.getElementById('product_amount').value;
		var currentVal = parseInt(amout);
		if (!isNaN(currentVal) && currentVal > 0) {
			document.getElementById('product_amount').value = currentVal-1;
		}else {
            // Otherwise put a 0 there
            document.getElementById('product_amount').value = 0;
        }
	}

$.fn.pageMe = function(opts){
    var $this = this,
        defaults = {
            perPage: 7,
            showPrevNext: false,
            hidePageNumbers: false
        },
        settings = $.extend(defaults, opts);
    
    var listElement = $this;
    var perPage = settings.perPage; 
    var children = listElement.children();
    var pager = $('.pager');
    
    if (typeof settings.childSelector!="undefined") {
        children = listElement.find(settings.childSelector);
    }
    
    if (typeof settings.pagerSelector!="undefined") {
        pager = $(settings.pagerSelector);
    }
    
    var numItems = children.size();
    var numPages = Math.ceil(numItems/perPage);

    pager.data("curr",0);
    
    if (settings.showPrevNext){
        $('<li><a href="#" class="prev_link">«</a></li>').appendTo(pager);
    }
    
    var curr = 0;
    while(numPages > curr && (settings.hidePageNumbers==false)){
        $('<li><a href="#" class="page_link">'+(curr+1)+'</a></li>').appendTo(pager);
        curr++;
    }
    
    if (settings.showPrevNext){
        $('<li><a href="#" class="next_link">»</a></li>').appendTo(pager);
    }
    
    pager.find('.page_link:first').addClass('active');
    pager.find('.prev_link').hide();
    if (numPages<=1) {
        pager.find('.next_link').hide();
    }
  	pager.children().eq(1).addClass("active");
    
    children.hide();
    children.slice(0, perPage).show();
    
    pager.find('li .page_link').click(function(){
        var clickedPage = $(this).html().valueOf()-1;
        goTo(clickedPage,perPage);
        return false;
    });
    pager.find('li .prev_link').click(function(){
        previous();
        return false;
    });
    pager.find('li .next_link').click(function(){
        next();
        return false;
    });
    
    function previous(){
        var goToPage = parseInt(pager.data("curr")) - 1;
        goTo(goToPage);
    }
     
    function next(){
        goToPage = parseInt(pager.data("curr")) + 1;
        goTo(goToPage);
    }
    
    function goTo(page){
        var startAt = page * perPage,
            endOn = startAt + perPage;
        
        children.css('display','none').slice(startAt, endOn).show();
        
        if (page>=1) {
            pager.find('.prev_link').show();
        }
        else {
            pager.find('.prev_link').hide();
        }
        
        if (page<(numPages-1)) {
            pager.find('.next_link').show();
        }
        else {
            pager.find('.next_link').hide();
        }
        
        pager.data("curr",page);
      	pager.children().removeClass("active");
        pager.children().eq(page+1).addClass("active");
    
    }
};

		$(document).ready(function() {
		    // $('input[type=radio][name=product_color]').change(function() {
		    //     alert('onclick');
		    // });

			$("#show_search_result").on("change","#product_color",function(){
			    //alert(this.value);
			    if ($( this ).parent().find("img").attr("src") != null) {
				    var tag = $( this ).parent().find("img").attr("src");
				    //alert(tag);
				    tag = tag.replace("30x30", "300x300");
				    tag = tag.replace("40x40", "300x300");
				    if (tag.match(/amazon.*/)) {
					  tag = tag.substr(0, tag.lastIndexOf('.')) || tag;
					  tag = tag.substr(0, tag.lastIndexOf('.')) || tag;
					  tag = tag+".jpg";
					}
				    //alert(tag);
				    if (tag!="") {
				    	$("#product_img").attr("src",tag);
				    };
				    
			    };

			});

		});







