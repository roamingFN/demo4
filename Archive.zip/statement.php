<?php
	include 'connect.php';
	include 'session.php';
	include 'inc/php/functions_statusConvert.php';
?>
<!DOCTYPE html>
<html>
  <head>
    <?php include 'page_script.php';  ?>
  </head>
  <body>
    <?php include 'nav_bar.php';  ?>
	<div class="content manage">
		<?php include 'left_menu.php' ?>
		<div class="menu-content col3">

	<h3><i class="material-icons">content_copy</i> รายการบัญชีลูกค้า</h3>
	<a class="button" href="excel/statement_generate.php" >ไฟล์ Excel</a>
	<br><a href="#" class="more" onclick='window.print()'>พิมพ์หน้านี้</a>
	<h1>รายละเอียดบัญชี</h1>



	<form role="form">
	<table class="content-grid">
		<tr class="bg-primary">
			<th>วันที่</th>
			<th>รายการ</th>
			<th>เลขที่ออเดอร์</th>
			<th>ประเภท</th>
			<th>ยอดเข้า</th>
			<th>ยอดออก</th>
			<th>คงเหลือ</th>
		</tr>
		
<?php

$total = 0;
$select_statement = mysql_query("select * from customer_statement s LEFT OUTER JOIN customer_order o ON s.order_id=o.order_id where s.customer_id = '$user_id' order by s.statement_date asc");
if (mysql_num_rows($select_statement) > 0) {
	while ($row = mysql_fetch_array($select_statement)) {
		$total += $row['debit'];
		$total -= $row['credit'];
		echo "
		<tr>
			<td>".date("d/m/Y G:i:s", strtotime($row['statement_date']))."</td>
			<td>".$row['statement_name']."</td>
			<td>".$row['order_number']."</td>
			<td>".$row['statement_detail']."</td>
			<td>".convertStatementZero(number_format($row['debit'],2))."</td>
			<td>".convertStatementZero(number_format($row['credit'],2))."</td>
			<td>".number_format($total,2)."</td>
		</tr>
		";
	}
}
?>

		<tr class="sub">
			<td></td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
			<td>ยอดเงินคงเหลือ</td>
			<td><?php echo number_format($total,2); ?></td>
		</tr>
	</table>
	</form>
	<br />
	<p><small>- รายการเติมเงินที่เป็นสถานะ "รอตรวจสอบ" จะไม่ขึ้นในบัญชีลูกค้า จนกระทั่งเปลี่ยนเป็นสถานะ "ตรวจสอบแล้ว"</small></p><br />
	<p><small>- ค่าสินค้าที่เป็นสถานะ "ยังไม่ได้Confirm" อาจมีการเปลี่ยนแปลงยอดเงินหลังจาก ที่มีการสั่งซื้อจริงกับทางร้านค้า</small></p><br />
	<p><small>- ในกรณีกดถอนเงิน เมื่อเจ้าหน้าที่ตรวจสอบผ่านแล้ว ระบบจะตัดเงินคงเหลือทันที แต่เงินจะเข้าบัญชีลูกค้าในช่วงระยะเวลาดำเนินการ 7-10 วัน</small></p>
	
</div>
	
</div>
        <?php include 'modal.php';  ?>
        <?php include 'footer.php';  ?>

        <script src="js/core.js"></script>
        <script type="text/javascript">

            function runScript(e) {
                if (e.keyCode == 13) {
                    searchURL();
                }
            }

        </script>
        <script src="dist/sweetalert.min.js"></script>
        <link rel="stylesheet" href="dist/sweetalert.css">
    </body>
</html>