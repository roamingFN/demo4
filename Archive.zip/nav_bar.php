<div class="header">
  <div class="header-menu">
    <div>
      <a id="logo" href="index.php"></a>
      <input id="searchText" type="search" placeholder="ค้นหา หรือ คัดลอกลิงค์สินค้าวางที่นี่..." style="vertical-align:middle;height:30px;line-height:150%;color:#000000;">
      <button id="search-btn" onclick="searchURL();"><i class="material-icons">search</i></button>
      <button id="clear-btn" class="menu-focus" onclick="clearURL();"><i class="material-icons">close</i></button>
      <button id="more-btn"><i class="material-icons">more_vert</i></button>
    </div>
    <div id="header-group">
      <a class="clickable" href="cart.php"><i class="material-icons">shopping_cart</i>
        <span class="badge">
          <?php 
          if (isset($_SESSION['CX_login_user'])) {
            $user_id = $_SESSION['CX_login_id'];
            $select_cart_item = mysql_query("select count(cart_id) from shopping_cart where customer_id = '$user_id'");
            $select_cart_item_row = mysql_fetch_array($select_cart_item);
            echo $select_cart_item_row['count(cart_id)']; 
          }else {
            echo "0";
          }

          ?>
        </span>
      </a>
      <a class="clickable" href="order_list.php">รายการสั่งซื้อ
        <span class="badge">
          <?php 
          if (isset($_SESSION['CX_login_user'])) {
            $user_id = $_SESSION['CX_login_id'];
            $select_order_item = mysql_query("select count(order_id) from customer_order where customer_id = '$user_id'");
            $select_order_item_row = mysql_fetch_array($select_order_item);
            echo $select_order_item_row['count(order_id)']; 
          }else{
            echo "0";
          }
          ?>
        </span>
      </a>
      <a href="cart.php" class="cart"><i class="material-icons">shopping_cart</i></a>
      <a href="order_list.php" class="list"><i class="material-icons">view_list</i></a>
      <?php
    if (isset($_SESSION['CX_login_user']) && !empty($_SESSION['CX_login_user'])) {
      echo '
      <div class="header-right">
        <a style="width:180px;" class="user" onclick="openSetting();">คุณ '.$_SESSION['CX_login_name'].' <i class="material-icons">account_circle</i></a>
      </div>
    </div> <!-- close header group -->
  </div> <!-- close header menu -->
</div>
<div id="setting" class="header-dialog-wrap">
  <div class="header-dialog">
    <a href="profile.php">ข้อมูลส่วนตัว</a>
    <a href="change_password.php">เปลี่ยนรหัสผ่าน</a>
    <a href="fav_shop.php">ร้านค้าที่ชื่นชอบ</a>
    <div class="header-line"></div>
    <a href="logout.php"><i class="material-icons">exit_to_app</i> ออกจากระบบ</a>
  </div>
</div>
  ';
    }else{
      echo '
      <div class="header-right">
        <a onclick="openRegister();">สมัครสมาชิก</a>
        <a onclick="openLogin();">เข้าสู่ระบบ</a>
      </div>
    </div>
  </div>
</div>
<div id="login" class="header-dialog-wrap">
  <div class="header-dialog">
    <form action="index.php" method="post" onsubmit="return checkLogin()">
      <h3 class="focus">เข้าสู่ระบบ Order<p class="orange">2</p>Easy</h3>

      <label class="control-label" id="help-login-email" style="color:red;"></label>
      <input placeholder="อีเมล" name="email" id="login-email" style="color:black" />

      <label class="control-label" id="help-login-password" style="color:red;"></label>
      <input placeholder="รหัสผ่าน" name="password" id="login-password" type="password" style="color:black" />
      <div id="line" style="width:100%;height:5px;"></div>
      <button name="submit" type="submit">เข้าใช้งาน</button>
    </form>
  </div>
</div>
<div id="register" class="header-dialog-wrap">
  <div class="header-dialog">
    <form id="signupform" action="register.php" method="post" onsubmit="return validateRegisterForm()">
      <h3 class="focus">สมัครสมาชิก Order<p class="orange">2</p>Easy</h3>

      <label class="control-label" id="help-register-email" style="color:red;"></label>
      <input name="email" id="register-email"  placeholder="อีเมล" style="color:black"/>

      <label class="control-label" id="help-register-password" style="color:red;"></label>
      <input name="password" id="register-password"  placeholder="รหัสผ่าน" type="password" style="color:black"/>

      <label class="control-label" id="help-register-firstname" style="color:red;"></label>
      <input name="firstname" id="register-firstname" placeholder="ชื่อ" style="color:black"/>

      <label class="control-label" id="help-register-lastname" style="color:red;"></label>
      <input name="lastname" id="register-lastname" placeholder="นามสกุล" style="color:black"/>

      <label class="control-label" id="help-register-phone" style="color:red;"></label>
      <input name="phone" id="register-phone" placeholder="หมายเลขโทรศัพท์" style="color:black"/>
      <div id="line" style="width:100%;height:5px;"></div>
      <button type="submit" name="signup">สมัครเดี๋ยวนี้</button>
    </form>
  </div>
</div>
';
}
?>
