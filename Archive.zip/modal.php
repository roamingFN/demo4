

  <!-- Modal Search -->
  <div class="modal fade" id="search_mdl" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">ค้นหาสินค้า</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal" role="form" action="" method="post" > 
            <div id="show_search_result" name="show_search_result"></div>
          </form> 
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary" id="addtocart_button" onclick="addtocart();"><span class="glyphicon glyphicon-shopping-cart"></span> หยิบใส่ตะกร้า</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Manual Add -->
  <div class="modal fade" id="manualadd" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">สั่งซื้อสินค้าแบบเก่า</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal" role="form" action="" method="post" > 
            <div class="row" id="show_manualadd" name="show_manualadd">
                  <div class="col-md-3 control-label"><label>ชื่อเว็บไซด์ : </label></div>
                  <div class="col-md-8"><input id="msource" type="text" class="form-control" placeholder="เช่น Taobao, T-mall, JD, Amazon.cn"><br></div>

                  <div class="col-md-3 control-label"><label>ลิงค์เว็บไซด์ : </label></div>
                  <div class="col-md-8"><input id="mproduct_url" type="text" class="form-control" placeholder="เช่น http://item.taobao.com/item.htm?id=520517112316"><br></div>
                  <div class="col-md-1">*</div>

                  <div class="col-md-3 control-label"><label>ชื่อร้านค้า: </label></div>
                  <div class="col-md-8"><input id="mshop_name" type="text" class="form-control" placeholder="ชื่อร้านค้า"><br></div>

                  <div class="col-md-3 control-label"><label>ชื่อสินค้า : </label></div>
                  <div class="col-md-8"><input id="mproduct_name" type="text" class="form-control" placeholder="ชื่อสินค้า"><br></div>
                  <div class="col-md-1">*</div>

                  <div class="col-md-3 control-label"><label>รูปสินค้า : </label></div>
                  <div class="col-md-8"><input id="mproduct_img" type="text" class="form-control" placeholder="รูปสินค้า"><br></div>
                  
                  <div class="col-md-3 control-label"><label>ราคา (¥) : </label></div>
                  <div class="col-md-8"><input id="mproduct_price" type="text" class="form-control" placeholder="ราคาสินค้า"><br></div>
                  <div class="col-md-1">*</div>

                  <div class="col-md-3 control-label"><label>ขนาด : </label></div>
                  <div class="col-md-8"><input id="mproduct_size" type="text" class="form-control" placeholder="ขนาดสินค้า"><br></div>
                  
                  <div class="col-md-3 control-label"><label>สี : </label></div>
                  <div class="col-md-8"><input id="mproduct_color" type="text" class="form-control" placeholder="กรอกสีสินค้า"><br></div>
                  
                  <div class="col-md-3 control-label"><label>จำนวน : </label></div>
                  <div class="col-md-8"><input id="mproduct_quantity" type="text" class="form-control" placeholder="จำนวนสินค้าที่ต้องการสั่ง"><br></div>
                  <div class="col-md-1">*</div>

            </div>
          </form> 
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary" id="addtocart_button" onclick="manual_addtocart();"><span class="glyphicon glyphicon-shopping-cart"></span> เพิ่มในตะกร้า</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Modal Add to Cart -->
  <div class="modal fade" id="addtocart" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">เพิ่มสินค้า</h4>
        </div>
        <div class="modal-body">
          <form id="loginform" class="form-horizontal" role="form" action="order.php" method="post" onsubmit="return addtocart()"> 
            <span id="show_addtocart_result" name="show_addtocart_result"></span>
          </form> 
        </div>
        <div class="modal-footer">
          <a href="cart.php"><button type="submit" class="btn btn-success" <?php if(!isset($_SESSION['CX_login_user'])){ echo "disabled";} ?>>ชำระเงิน</button></a>
          <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.reload();">ซื้อสินค้าต่อ</button>
        </div>
      </div>
    </div>
  </div>


